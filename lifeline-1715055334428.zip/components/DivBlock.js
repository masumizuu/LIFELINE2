import React from 'react';
import * as GlobalStyles from '../GlobalStyles.js';
import Breakpoints from '../utils/Breakpoints';
import * as StyleSheet from '../utils/StyleSheet';
import useWindowDimensions from '../utils/useWindowDimensions';
import { Divider, withTheme } from '@draftbit/ui';

const DivBlock = props => {
  const { theme } = props;
  const dimensions = useWindowDimensions();

  return (
    <Divider
      {...GlobalStyles.DividerStyles(theme)['Divider'].props}
      color={theme.colors['Medium']}
      style={StyleSheet.applyWidth(
        StyleSheet.compose(GlobalStyles.DividerStyles(theme)['Divider'].style, {
          marginBottom: 8,
          marginLeft: 10,
          marginRight: 10,
          marginTop: 8,
        }),
        dimensions.width
      )}
    />
  );
};

export default withTheme(DivBlock);
