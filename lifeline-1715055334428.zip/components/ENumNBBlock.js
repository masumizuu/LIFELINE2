import React from 'react';
import Breakpoints from '../utils/Breakpoints';
import * as StyleSheet from '../utils/StyleSheet';
import useWindowDimensions from '../utils/useWindowDimensions';
import { Icon, Touchable, withTheme } from '@draftbit/ui';
import { useNavigation } from '@react-navigation/native';
import { View } from 'react-native';

const ENumNBBlock = props => {
  const { theme } = props;
  const dimensions = useWindowDimensions();
  const navigation = useNavigation();

  return (
    <View
      style={StyleSheet.applyWidth(
        {
          alignContent: 'center',
          alignItems: 'flex-end',
          backgroundColor: theme.colors['Surface'],
          bottom: 0,
          flexDirection: 'row',
          justifyContent: 'space-between',
          paddingLeft: 10,
          paddingRight: 10,
          position: 'absolute',
          width: '100%',
        },
        dimensions.width
      )}
    >
      {/* Homey */}
      <Touchable
        onPress={() => {
          try {
            if (navigation.canGoBack()) {
              navigation.popToTop();
            }
            navigation.replace('HomeScreen');
          } catch (err) {
            console.error(err);
          }
        }}
        disabledOpacity={0.8}
      >
        {/* Viewy */}
        <View
          style={StyleSheet.applyWidth(
            {
              alignItems: 'center',
              height: 48,
              justifyContent: 'center',
              width: 48,
            },
            dimensions.width
          )}
        >
          {/* Icony */}
          <Icon
            size={24}
            color={theme.colors['Medium']}
            name={'Feather/home'}
          />
        </View>
      </Touchable>
      {/* Earthquakes Dashboardy */}
      <Touchable
        onPress={() => {
          try {
            if (navigation.canGoBack()) {
              navigation.popToTop();
            }
            navigation.replace('EarthquakeDashboardScreen');
          } catch (err) {
            console.error(err);
          }
        }}
        activeOpacity={0.8}
        disabledOpacity={0.8}
      >
        {/* Viewyy */}
        <View
          style={StyleSheet.applyWidth(
            {
              alignItems: 'center',
              borderBottomLeftRadius: 10,
              borderBottomRightRadius: 10,
              height: 48,
              justifyContent: 'center',
              width: 48,
            },
            dimensions.width
          )}
        >
          {/* Iconyy */}
          <Icon
            size={24}
            color={theme.colors['Medium']}
            name={'MaterialCommunityIcons/view-dashboard-outline'}
          />
        </View>
      </Touchable>
      {/* Evacuation Centersy */}
      <Touchable
        onPress={() => {
          try {
            if (navigation.canGoBack()) {
              navigation.popToTop();
            }
            navigation.replace('EvacuationCentersScreen');
          } catch (err) {
            console.error(err);
          }
        }}
        activeOpacity={0.8}
        disabledOpacity={0.8}
      >
        {/* Viewyyy */}
        <View
          style={StyleSheet.applyWidth(
            {
              alignItems: 'center',
              borderBottomLeftRadius: 10,
              borderBottomRightRadius: 10,
              height: 48,
              justifyContent: 'center',
              width: 48,
            },
            dimensions.width
          )}
        >
          {/* Iconyyy */}
          <Icon size={24} color={theme.colors['Medium']} name={'Entypo/map'} />
        </View>
      </Touchable>
      {/* Emergency Numbersy */}
      <Touchable
        onPress={() => {
          try {
            if (navigation.canGoBack()) {
              navigation.popToTop();
            }
            navigation.replace('EmergencyNumbersScreen');
          } catch (err) {
            console.error(err);
          }
        }}
        activeOpacity={0.8}
        disabledOpacity={0.8}
      >
        {/* Viewyyyy */}
        <View
          style={StyleSheet.applyWidth(
            {
              alignItems: 'center',
              backgroundColor: theme.colors['Primary'],
              borderBottomLeftRadius: 10,
              borderBottomRightRadius: 10,
              height: 48,
              justifyContent: 'center',
              width: 48,
            },
            dimensions.width
          )}
        >
          {/* Iconyyyy */}
          <Icon
            size={24}
            color={theme.colors['Surface']}
            name={'Ionicons/md-call'}
          />
        </View>
      </Touchable>
      {/* Emergency Proceduresy */}
      <Touchable
        onPress={() => {
          try {
            if (navigation.canGoBack()) {
              navigation.popToTop();
            }
            navigation.replace('EmergencyProceduresScreen');
          } catch (err) {
            console.error(err);
          }
        }}
        activeOpacity={0.8}
        disabledOpacity={0.8}
      >
        {/* Viewyyyyy */}
        <View
          style={StyleSheet.applyWidth(
            {
              alignItems: 'center',
              height: 48,
              justifyContent: 'center',
              width: 48,
            },
            dimensions.width
          )}
        >
          {/* Iconyyyyy */}
          <Icon
            size={24}
            color={theme.colors['Primary']}
            name={'MaterialCommunityIcons/file-document-outline'}
          />
        </View>
      </Touchable>
      {/* Settingsy */}
      <Touchable
        onPress={() => {
          try {
            if (navigation.canGoBack()) {
              navigation.popToTop();
            }
            navigation.replace('SettingsScreen');
          } catch (err) {
            console.error(err);
          }
        }}
        activeOpacity={0.8}
        disabledOpacity={0.8}
      >
        {/* Viewyyyyyy */}
        <View
          style={StyleSheet.applyWidth(
            {
              alignItems: 'center',
              height: 48,
              justifyContent: 'center',
              width: 48,
            },
            dimensions.width
          )}
        >
          {/* Iconyyyyyy */}
          <Icon
            size={24}
            color={theme.colors['Primary']}
            name={'Feather/settings'}
          />
        </View>
      </Touchable>
    </View>
  );
};

export default withTheme(ENumNBBlock);
