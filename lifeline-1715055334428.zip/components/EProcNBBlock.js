import React from 'react';
import Breakpoints from '../utils/Breakpoints';
import * as StyleSheet from '../utils/StyleSheet';
import useWindowDimensions from '../utils/useWindowDimensions';
import { Icon, Touchable, withTheme } from '@draftbit/ui';
import { useNavigation } from '@react-navigation/native';
import { View } from 'react-native';

const EProcNBBlock = props => {
  const { theme } = props;
  const dimensions = useWindowDimensions();
  const navigation = useNavigation();

  return (
    <View
      style={StyleSheet.applyWidth(
        {
          alignContent: 'center',
          alignItems: 'flex-end',
          backgroundColor: theme.colors['Surface'],
          bottom: 0,
          flexDirection: 'row',
          justifyContent: 'space-between',
          paddingLeft: 10,
          paddingRight: 10,
          position: 'absolute',
          width: '100%',
        },
        dimensions.width
      )}
    >
      {/* Homez */}
      <Touchable
        onPress={() => {
          try {
            if (navigation.canGoBack()) {
              navigation.popToTop();
            }
            navigation.replace('HomeScreen');
          } catch (err) {
            console.error(err);
          }
        }}
        disabledOpacity={0.8}
      >
        {/* Viewz */}
        <View
          style={StyleSheet.applyWidth(
            {
              alignItems: 'center',
              height: 48,
              justifyContent: 'center',
              width: 48,
            },
            dimensions.width
          )}
        >
          {/* Iconz */}
          <Icon
            size={24}
            color={theme.colors['Medium']}
            name={'Feather/home'}
          />
        </View>
      </Touchable>
      {/* Earthquakes Dashboardz */}
      <Touchable
        onPress={() => {
          try {
            if (navigation.canGoBack()) {
              navigation.popToTop();
            }
            navigation.replace('EarthquakeDashboardScreen');
          } catch (err) {
            console.error(err);
          }
        }}
        activeOpacity={0.8}
        disabledOpacity={0.8}
      >
        {/* Viewzz */}
        <View
          style={StyleSheet.applyWidth(
            {
              alignItems: 'center',
              borderBottomLeftRadius: 10,
              borderBottomRightRadius: 10,
              height: 48,
              justifyContent: 'center',
              width: 48,
            },
            dimensions.width
          )}
        >
          {/* Iconzz */}
          <Icon
            size={24}
            color={theme.colors['Medium']}
            name={'MaterialCommunityIcons/view-dashboard-outline'}
          />
        </View>
      </Touchable>
      {/* Evacuation Centersz */}
      <Touchable
        onPress={() => {
          try {
            if (navigation.canGoBack()) {
              navigation.popToTop();
            }
            navigation.replace('EvacuationCentersScreen');
          } catch (err) {
            console.error(err);
          }
        }}
        activeOpacity={0.8}
        disabledOpacity={0.8}
      >
        {/* Viewzzz */}
        <View
          style={StyleSheet.applyWidth(
            {
              alignItems: 'center',
              borderBottomLeftRadius: 10,
              borderBottomRightRadius: 10,
              height: 48,
              justifyContent: 'center',
              width: 48,
            },
            dimensions.width
          )}
        >
          {/* Iconzzz */}
          <Icon size={24} color={theme.colors['Medium']} name={'Entypo/map'} />
        </View>
      </Touchable>
      {/* Emergency Numbersz */}
      <Touchable
        onPress={() => {
          try {
            if (navigation.canGoBack()) {
              navigation.popToTop();
            }
            navigation.replace('EmergencyNumbersScreen');
          } catch (err) {
            console.error(err);
          }
        }}
        activeOpacity={0.8}
        disabledOpacity={0.8}
      >
        {/* Viewzzzz */}
        <View
          style={StyleSheet.applyWidth(
            {
              alignItems: 'center',
              borderBottomLeftRadius: 10,
              borderBottomRightRadius: 10,
              height: 48,
              justifyContent: 'center',
              width: 48,
            },
            dimensions.width
          )}
        >
          {/* Iconzzzz */}
          <Icon
            size={24}
            color={theme.colors['Medium']}
            name={'Feather/phone'}
          />
        </View>
      </Touchable>
      {/* Emergency Proceduresz */}
      <Touchable
        onPress={() => {
          try {
            if (navigation.canGoBack()) {
              navigation.popToTop();
            }
            navigation.replace('EmergencyProceduresScreen');
          } catch (err) {
            console.error(err);
          }
        }}
        activeOpacity={0.8}
        disabledOpacity={0.8}
      >
        {/* Viewzzzzz */}
        <View
          style={StyleSheet.applyWidth(
            {
              alignItems: 'center',
              backgroundColor: theme.colors['Primary'],
              borderBottomLeftRadius: 10,
              borderBottomRightRadius: 10,
              height: 48,
              justifyContent: 'center',
              width: 48,
            },
            dimensions.width
          )}
        >
          {/* Iconzzzzz */}
          <Icon
            size={24}
            color={theme.colors['Surface']}
            name={'MaterialCommunityIcons/file-document'}
          />
        </View>
      </Touchable>
      {/* Settingsz */}
      <Touchable
        onPress={() => {
          try {
            if (navigation.canGoBack()) {
              navigation.popToTop();
            }
            navigation.replace('SettingsScreen');
          } catch (err) {
            console.error(err);
          }
        }}
        activeOpacity={0.8}
        disabledOpacity={0.8}
      >
        {/* Viewzzzzzz */}
        <View
          style={StyleSheet.applyWidth(
            {
              alignItems: 'center',
              height: 48,
              justifyContent: 'center',
              width: 48,
            },
            dimensions.width
          )}
        >
          {/* Iconzzzzzz */}
          <Icon
            size={24}
            color={theme.colors['Primary']}
            name={'Feather/settings'}
          />
        </View>
      </Touchable>
    </View>
  );
};

export default withTheme(EProcNBBlock);
