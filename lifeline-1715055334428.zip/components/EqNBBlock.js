import React from 'react';
import Breakpoints from '../utils/Breakpoints';
import * as StyleSheet from '../utils/StyleSheet';
import useWindowDimensions from '../utils/useWindowDimensions';
import { Icon, Touchable, withTheme } from '@draftbit/ui';
import { useNavigation } from '@react-navigation/native';
import { View } from 'react-native';

const EqNBBlock = props => {
  const { theme } = props;
  const dimensions = useWindowDimensions();
  const navigation = useNavigation();

  return (
    <View
      style={StyleSheet.applyWidth(
        {
          alignContent: 'center',
          alignItems: 'flex-end',
          backgroundColor: theme.colors['Surface'],
          bottom: 0,
          flexDirection: 'row',
          justifyContent: 'space-between',
          paddingLeft: 10,
          paddingRight: 10,
          position: 'absolute',
          width: '100%',
        },
        dimensions.width
      )}
    >
      {/* homet */}
      <Touchable
        onPress={() => {
          try {
            if (navigation.canGoBack()) {
              navigation.popToTop();
            }
            navigation.replace('HomeScreen');
          } catch (err) {
            console.error(err);
          }
        }}
        disabledOpacity={0.8}
      >
        {/* Viewt */}
        <View
          style={StyleSheet.applyWidth(
            {
              alignItems: 'center',
              height: 48,
              justifyContent: 'center',
              width: 48,
            },
            dimensions.width
          )}
        >
          {/* Icont */}
          <Icon
            size={24}
            color={theme.colors['Medium']}
            name={'Feather/home'}
          />
        </View>
      </Touchable>
      {/* Earthquakes Dashboardt */}
      <Touchable
        onPress={() => {
          try {
            if (navigation.canGoBack()) {
              navigation.popToTop();
            }
            navigation.replace('EarthquakeDashboardScreen');
          } catch (err) {
            console.error(err);
          }
        }}
        activeOpacity={0.8}
        disabledOpacity={0.8}
      >
        {/* viewtt */}
        <View
          style={StyleSheet.applyWidth(
            {
              alignItems: 'center',
              backgroundColor: theme.colors['Primary'],
              borderBottomLeftRadius: 10,
              borderBottomRightRadius: 10,
              height: 48,
              justifyContent: 'center',
              width: 48,
            },
            dimensions.width
          )}
        >
          {/* Icontt */}
          <Icon
            size={24}
            color={theme.colors['Surface']}
            name={'MaterialCommunityIcons/view-dashboard'}
          />
        </View>
      </Touchable>
      {/* Evacuation Centerst */}
      <Touchable
        onPress={() => {
          try {
            if (navigation.canGoBack()) {
              navigation.popToTop();
            }
            navigation.replace('EvacuationCentersScreen');
          } catch (err) {
            console.error(err);
          }
        }}
        activeOpacity={0.8}
        disabledOpacity={0.8}
      >
        {/* Viewttt */}
        <View
          style={StyleSheet.applyWidth(
            {
              alignItems: 'center',
              height: 48,
              justifyContent: 'center',
              width: 48,
            },
            dimensions.width
          )}
        >
          {/* Iconttt */}
          <Icon size={24} color={theme.colors['Medium']} name={'Entypo/map'} />
        </View>
      </Touchable>
      {/* Emergency Numberst */}
      <Touchable
        onPress={() => {
          try {
            if (navigation.canGoBack()) {
              navigation.popToTop();
            }
            navigation.replace('EmergencyNumbersScreen');
          } catch (err) {
            console.error(err);
          }
        }}
        activeOpacity={0.8}
        disabledOpacity={0.8}
      >
        {/* Viewtttt */}
        <View
          style={StyleSheet.applyWidth(
            {
              alignItems: 'center',
              height: 48,
              justifyContent: 'center',
              width: 48,
            },
            dimensions.width
          )}
        >
          {/* Icontttt */}
          <Icon
            size={24}
            color={theme.colors['Medium']}
            name={'Feather/phone'}
          />
        </View>
      </Touchable>
      {/* Emergency Procedurest */}
      <Touchable
        onPress={() => {
          try {
            if (navigation.canGoBack()) {
              navigation.popToTop();
            }
            navigation.replace('EmergencyProceduresScreen');
          } catch (err) {
            console.error(err);
          }
        }}
        activeOpacity={0.8}
        disabledOpacity={0.8}
      >
        {/* Viewttttt */}
        <View
          style={StyleSheet.applyWidth(
            {
              alignItems: 'center',
              height: 48,
              justifyContent: 'center',
              width: 48,
            },
            dimensions.width
          )}
        >
          {/* Iconttttt */}
          <Icon
            size={24}
            color={theme.colors['Primary']}
            name={'MaterialCommunityIcons/file-document-outline'}
          />
        </View>
      </Touchable>
      {/* Settingst */}
      <Touchable
        onPress={() => {
          try {
            if (navigation.canGoBack()) {
              navigation.popToTop();
            }
            navigation.replace('SettingsScreen');
          } catch (err) {
            console.error(err);
          }
        }}
        activeOpacity={0.8}
        disabledOpacity={0.8}
      >
        {/* Viewtttttt */}
        <View
          style={StyleSheet.applyWidth(
            {
              alignItems: 'center',
              height: 48,
              justifyContent: 'center',
              width: 48,
            },
            dimensions.width
          )}
        >
          {/* Icontttttt */}
          <Icon
            size={24}
            color={theme.colors['Primary']}
            name={'Feather/settings'}
          />
        </View>
      </Touchable>
    </View>
  );
};

export default withTheme(EqNBBlock);
