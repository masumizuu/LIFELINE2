import React from 'react';
import Breakpoints from '../utils/Breakpoints';
import * as StyleSheet from '../utils/StyleSheet';
import useWindowDimensions from '../utils/useWindowDimensions';
import { IconButton, withTheme } from '@draftbit/ui';
import { Text, View } from 'react-native';

const EvacuationCenterDetailsBlock = props => {
  const { theme } = props;
  const dimensions = useWindowDimensions();

  return (
    <View
      style={StyleSheet.applyWidth(
        {
          backgroundColor: theme.colors['Custom Color'],
          bottom: 0,
          flexDirection: 'column',
          justifyContent: 'space-between',
          left: 0,
          paddingBottom: 10,
          position: 'relative',
          right: 0,
        },
        dimensions.width
      )}
    >
      <View
        style={StyleSheet.applyWidth(
          {
            alignItems: 'center',
            backgroundColor: theme.colors['Custom Color'],
            borderRadius: 12,
            flexDirection: 'row',
            height: 84,
            paddingBottom: 20,
            paddingLeft: 12,
            paddingRight: 12,
            paddingTop: 20,
          },
          dimensions.width
        )}
      >
        <View
          style={StyleSheet.applyWidth(
            { alignItems: 'flex-start', flex: 1, marginLeft: 15 },
            dimensions.width
          )}
        >
          {/* Name */}
          <Text
            accessible={true}
            style={StyleSheet.applyWidth(
              {
                color: theme.colors['Primary'],
                fontFamily: 'Inter_500Medium',
                fontSize: 16,
                marginTop: 12,
              },
              dimensions.width
            )}
          >
            {'Medika Husada Hospital'}
          </Text>
          {/* Address */}
          <Text
            accessible={true}
            style={StyleSheet.applyWidth(
              {
                color: theme.colors['Studily_Light_Gray_2'],
                fontFamily: 'Inter_300Light',
                fontSize: 12,
                marginTop: 5,
                opacity: 0.7,
              },
              dimensions.width
            )}
          >
            {'Jl. Prapatan No 26, Labuan, Malang'}
          </Text>
        </View>
        {/* Actions */}
        <View
          style={StyleSheet.applyWidth(
            {
              alignItems: 'flex-end',
              backgroundColor: 'rgba(0, 0, 0, 0)',
              flexDirection: 'row',
              height: 48,
              justifyContent: 'flex-end',
              paddingRight: 12,
            },
            dimensions.width
          )}
        >
          <IconButton
            size={32}
            color={theme.colors['Secondary']}
            icon={'Entypo/direction'}
          />
        </View>
      </View>
    </View>
  );
};

export default withTheme(EvacuationCenterDetailsBlock);
