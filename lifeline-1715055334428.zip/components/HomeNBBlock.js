import React from 'react';
import Breakpoints from '../utils/Breakpoints';
import * as StyleSheet from '../utils/StyleSheet';
import useWindowDimensions from '../utils/useWindowDimensions';
import { Icon, Touchable, withTheme } from '@draftbit/ui';
import { useNavigation } from '@react-navigation/native';
import { View } from 'react-native';

const HomeNBBlock = props => {
  const { theme } = props;
  const dimensions = useWindowDimensions();
  const navigation = useNavigation();

  return (
    <View
      style={StyleSheet.applyWidth(
        {
          alignContent: 'center',
          alignItems: 'flex-end',
          backgroundColor: theme.colors['Surface'],
          bottom: 0,
          flexDirection: 'row',
          justifyContent: 'space-between',
          paddingLeft: 10,
          paddingRight: 10,
          position: 'absolute',
          width: '100%',
        },
        dimensions.width
      )}
    >
      {/* HomeR */}
      <Touchable
        onPress={() => {
          try {
            if (navigation.canGoBack()) {
              navigation.popToTop();
            }
            navigation.replace('HomeScreen');
          } catch (err) {
            console.error(err);
          }
        }}
        disabledOpacity={0.8}
      >
        {/* BYU12 */}
        <View
          style={StyleSheet.applyWidth(
            {
              alignItems: 'center',
              backgroundColor: theme.colors['Primary'],
              borderBottomLeftRadius: 10,
              borderBottomRightRadius: 10,
              height: 48,
              justifyContent: 'center',
              width: 48,
            },
            dimensions.width
          )}
        >
          {/* I12 */}
          <Icon
            color={theme.colors['Surface']}
            name={'Foundation/home'}
            size={26}
          />
        </View>
      </Touchable>
      {/* Earthquakes DashboardR */}
      <Touchable
        onPress={() => {
          try {
            if (navigation.canGoBack()) {
              navigation.popToTop();
            }
            navigation.replace('EarthquakeDashboardScreen');
          } catch (err) {
            console.error(err);
          }
        }}
        activeOpacity={0.8}
        disabledOpacity={0.8}
      >
        {/* BYU23 */}
        <View
          style={StyleSheet.applyWidth(
            {
              alignItems: 'center',
              height: 48,
              justifyContent: 'center',
              width: 48,
            },
            dimensions.width
          )}
        >
          {/* I23 */}
          <Icon
            size={24}
            color={theme.colors['Medium']}
            name={'MaterialCommunityIcons/view-dashboard-outline'}
          />
        </View>
      </Touchable>
      {/* Evacuation CentersR */}
      <Touchable
        onPress={() => {
          try {
            if (navigation.canGoBack()) {
              navigation.popToTop();
            }
            navigation.replace('EvacuationCentersScreen');
          } catch (err) {
            console.error(err);
          }
        }}
        activeOpacity={0.8}
        disabledOpacity={0.8}
      >
        {/* BYU34 */}
        <View
          style={StyleSheet.applyWidth(
            {
              alignItems: 'center',
              height: 48,
              justifyContent: 'center',
              width: 48,
            },
            dimensions.width
          )}
        >
          {/* I34 */}
          <Icon size={24} color={theme.colors['Medium']} name={'Entypo/map'} />
        </View>
      </Touchable>
      {/* Emergency NumbersR */}
      <Touchable
        onPress={() => {
          try {
            if (navigation.canGoBack()) {
              navigation.popToTop();
            }
            navigation.replace('EmergencyNumbersScreen');
          } catch (err) {
            console.error(err);
          }
        }}
        activeOpacity={0.8}
        disabledOpacity={0.8}
      >
        {/* BYU45 */}
        <View
          style={StyleSheet.applyWidth(
            {
              alignItems: 'center',
              height: 48,
              justifyContent: 'center',
              width: 48,
            },
            dimensions.width
          )}
        >
          {/* I45 */}
          <Icon
            size={24}
            color={theme.colors['Medium']}
            name={'Feather/phone'}
          />
        </View>
      </Touchable>
      {/* Emergency ProceduresR */}
      <Touchable
        onPress={() => {
          try {
            if (navigation.canGoBack()) {
              navigation.popToTop();
            }
            navigation.replace('EmergencyProceduresScreen');
          } catch (err) {
            console.error(err);
          }
        }}
        activeOpacity={0.8}
        disabledOpacity={0.8}
      >
        {/* BYU56 */}
        <View
          style={StyleSheet.applyWidth(
            {
              alignItems: 'center',
              height: 48,
              justifyContent: 'center',
              width: 48,
            },
            dimensions.width
          )}
        >
          {/* I56 */}
          <Icon
            size={24}
            color={theme.colors['Primary']}
            name={'MaterialCommunityIcons/file-document-outline'}
          />
        </View>
      </Touchable>
      {/* SettingsR */}
      <Touchable
        onPress={() => {
          try {
            if (navigation.canGoBack()) {
              navigation.popToTop();
            }
            navigation.replace('SettingsScreen');
          } catch (err) {
            console.error(err);
          }
        }}
        activeOpacity={0.8}
        disabledOpacity={0.8}
      >
        {/* BYU78 */}
        <View
          style={StyleSheet.applyWidth(
            {
              alignItems: 'center',
              height: 48,
              justifyContent: 'center',
              width: 48,
            },
            dimensions.width
          )}
        >
          {/* I78 */}
          <Icon
            size={24}
            color={theme.colors['Primary']}
            name={'Feather/settings'}
          />
        </View>
      </Touchable>
    </View>
  );
};

export default withTheme(HomeNBBlock);
