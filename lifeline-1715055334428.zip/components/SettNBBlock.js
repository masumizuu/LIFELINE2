import React from 'react';
import Breakpoints from '../utils/Breakpoints';
import * as StyleSheet from '../utils/StyleSheet';
import useWindowDimensions from '../utils/useWindowDimensions';
import { Icon, Touchable, withTheme } from '@draftbit/ui';
import { useNavigation } from '@react-navigation/native';
import { View } from 'react-native';

const SettNBBlock = props => {
  const { theme } = props;
  const dimensions = useWindowDimensions();
  const navigation = useNavigation();

  return (
    <View
      style={StyleSheet.applyWidth(
        {
          alignContent: 'center',
          alignItems: 'flex-end',
          backgroundColor: theme.colors['Surface'],
          bottom: 0,
          flexDirection: 'row',
          justifyContent: 'space-between',
          paddingLeft: 10,
          paddingRight: 10,
          position: 'absolute',
          width: '100%',
        },
        dimensions.width
      )}
    >
      {/* Homej */}
      <Touchable
        onPress={() => {
          try {
            if (navigation.canGoBack()) {
              navigation.popToTop();
            }
            navigation.replace('HomeScreen');
          } catch (err) {
            console.error(err);
          }
        }}
        disabledOpacity={0.8}
      >
        {/* Viewj */}
        <View
          style={StyleSheet.applyWidth(
            {
              alignItems: 'center',
              height: 48,
              justifyContent: 'center',
              width: 48,
            },
            dimensions.width
          )}
        >
          {/* Iconj */}
          <Icon
            size={24}
            color={theme.colors['Medium']}
            name={'Feather/home'}
          />
        </View>
      </Touchable>
      {/* Earthquakes Dashboardj */}
      <Touchable
        onPress={() => {
          try {
            navigation.navigate('EarthquakeDashboardScreen');
          } catch (err) {
            console.error(err);
          }
        }}
        activeOpacity={0.8}
        disabledOpacity={0.8}
      >
        {/* Viewjj */}
        <View
          style={StyleSheet.applyWidth(
            {
              alignItems: 'center',
              borderBottomLeftRadius: 10,
              borderBottomRightRadius: 10,
              height: 48,
              justifyContent: 'center',
              width: 48,
            },
            dimensions.width
          )}
        >
          {/* Iconjj */}
          <Icon
            size={24}
            color={theme.colors['Medium']}
            name={'MaterialCommunityIcons/view-dashboard-outline'}
          />
        </View>
      </Touchable>
      {/* Evacuation Centersj */}
      <Touchable
        onPress={() => {
          try {
            navigation.navigate('EvacuationCentersScreen');
          } catch (err) {
            console.error(err);
          }
        }}
        activeOpacity={0.8}
        disabledOpacity={0.8}
      >
        {/* Viewjjj */}
        <View
          style={StyleSheet.applyWidth(
            {
              alignItems: 'center',
              borderBottomLeftRadius: 10,
              borderBottomRightRadius: 10,
              height: 48,
              justifyContent: 'center',
              width: 48,
            },
            dimensions.width
          )}
        >
          {/* Iconjjj */}
          <Icon size={24} color={theme.colors['Medium']} name={'Entypo/map'} />
        </View>
      </Touchable>
      {/* Emergency Numbersj */}
      <Touchable
        onPress={() => {
          try {
            navigation.navigate('EmergencyNumbersScreen');
          } catch (err) {
            console.error(err);
          }
        }}
        activeOpacity={0.8}
        disabledOpacity={0.8}
      >
        {/* Viewjjjj */}
        <View
          style={StyleSheet.applyWidth(
            {
              alignItems: 'center',
              borderBottomLeftRadius: 10,
              borderBottomRightRadius: 10,
              height: 48,
              justifyContent: 'center',
              width: 48,
            },
            dimensions.width
          )}
        >
          {/* Iconjjjj */}
          <Icon
            size={24}
            color={theme.colors['Medium']}
            name={'Feather/phone'}
          />
        </View>
      </Touchable>
      {/* Emergency Proceduresj */}
      <Touchable
        onPress={() => {
          try {
            navigation.navigate('EmergencyProceduresScreen');
          } catch (err) {
            console.error(err);
          }
        }}
        activeOpacity={0.8}
        disabledOpacity={0.8}
      >
        {/* Viewjjjjj */}
        <View
          style={StyleSheet.applyWidth(
            {
              alignItems: 'center',
              borderBottomLeftRadius: 10,
              borderBottomRightRadius: 10,
              height: 48,
              justifyContent: 'center',
              width: 48,
            },
            dimensions.width
          )}
        >
          {/* Iconjjjjj */}
          <Icon
            size={24}
            color={theme.colors['Medium']}
            name={'MaterialCommunityIcons/file-document-outline'}
          />
        </View>
      </Touchable>
      {/* Settingsj */}
      <Touchable
        onPress={() => {
          try {
            navigation.navigate('SettingsScreen');
          } catch (err) {
            console.error(err);
          }
        }}
        activeOpacity={0.8}
        disabledOpacity={0.8}
      >
        {/* Viewjjjjjj */}
        <View
          style={StyleSheet.applyWidth(
            {
              alignItems: 'center',
              backgroundColor: theme.colors['Primary'],
              borderBottomLeftRadius: 10,
              borderBottomRightRadius: 10,
              height: 48,
              justifyContent: 'center',
              width: 48,
            },
            dimensions.width
          )}
        >
          {/* Iconjjjjjj */}
          <Icon
            size={24}
            color={theme.colors['Surface']}
            name={'Feather/settings'}
          />
        </View>
      </Touchable>
    </View>
  );
};

export default withTheme(SettNBBlock);
