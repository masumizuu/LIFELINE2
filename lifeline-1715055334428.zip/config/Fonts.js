export default {
  Inter_300Light: require('../assets/fonts/Inter_300Light.ttf'),
  Inter_400Regular: require('../assets/fonts/Inter_400Regular.ttf'),
  Inter_500Medium: require('../assets/fonts/Inter_500Medium.ttf'),
  Inter_600SemiBold: require('../assets/fonts/Inter_600SemiBold.ttf'),
  Inter_800ExtraBold: require('../assets/fonts/Inter_800ExtraBold.ttf'),
  Inter_900Black: require('../assets/fonts/Inter_900Black.ttf'),
  Inter_700Bold: require('../assets/fonts/Inter_700Bold.ttf'),
  Nunito_700Bold: require('../assets/fonts/Nunito_700Bold.ttf'),
};
