import React from 'react';

const switchFunc = () => {
  // At the start of your component
  const [locationPermission, setLocationPermission] = useState(false);
  const [notificationPermission, setNotificationPermission] = useState(false);

  useEffect(() => {
    // Check location permission
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        () => setLocationPermission(true),
        () => setLocationPermission(false)
      );
    }

    // Check notification permission
    if ('Notification' in window) {
      setNotificationPermission(Notification.permission === 'granted');
    }
  }, []);

  const handlePermission = (permissionType, isAllowed) => {
    if (permissionType === 'location') {
      if (isAllowed) {
        navigator.permissions.revoke({ name: 'geolocation' });
        setLocationPermission(false);
      } else {
        if ('geolocation' in navigator) {
          navigator.geolocation.getCurrentPosition(
            () => setLocationPermission(true),
            () => setLocationPermission(false)
          );
        }
      }
    } else if (permissionType === 'notification') {
      if (isAllowed) {
        Notification.permission = 'default';
        setNotificationPermission(false);
      } else {
        if ('Notification' in window) {
          Notification.requestPermission().then(permission => {
            setNotificationPermission(permission === 'granted');
          });
        }
      }
    }
  };
};

export default switchFunc;
