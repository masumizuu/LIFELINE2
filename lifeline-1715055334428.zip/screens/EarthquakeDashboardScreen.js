import React from 'react';
import * as GlobalStyles from '../GlobalStyles.js';
import EqNBBlock from '../components/EqNBBlock';
import Breakpoints from '../utils/Breakpoints';
import * as StyleSheet from '../utils/StyleSheet';
import useWindowDimensions from '../utils/useWindowDimensions';
import { ScreenContainer, WebView, withTheme } from '@draftbit/ui';
import { Modal, View } from 'react-native';

const EarthquakeDashboardScreen = props => {
  const { theme } = props;
  const dimensions = useWindowDimensions();

  return (
    <ScreenContainer
      hasSafeArea={false}
      scrollable={false}
      style={StyleSheet.applyWidth(
        { backgroundColor: theme.colors['Primary'] },
        dimensions.width
      )}
    >
      {/* mo */}
      <Modal animationType={'none'} transparent={false}>
        {/* wv */}
        <WebView
          allowFileAccessFromFileURLs={false}
          allowUniversalAccessFromFileURLs={false}
          cacheEnabled={true}
          incognito={false}
          javaScriptCanOpenWindowsAutomatically={false}
          javaScriptEnabled={true}
          mediaPlaybackRequiresUserAction={false}
          showsHorizontalScrollIndicator={true}
          showsVerticalScrollIndicator={true}
          startInLoadingState={false}
          {...GlobalStyles.WebViewStyles(theme)['Web View'].props}
          source={{ uri: 'https://earthquake.phivolcs.dost.gov.ph/' }}
          style={StyleSheet.applyWidth(
            StyleSheet.compose(
              GlobalStyles.WebViewStyles(theme)['Web View'].style,
              { borderColor: theme.colors['Primary'], marginBottom: 45 }
            ),
            dimensions.width
          )}
        />
        {/* puter */}
        <View
          style={StyleSheet.applyWidth(
            {
              backgroundColor: theme.colors['Primary'],
              bottom: 0,
              position: 'absolute',
              width: '100%',
            },
            dimensions.width
          )}
        >
          <EqNBBlock />
        </View>
      </Modal>
    </ScreenContainer>
  );
};

export default withTheme(EarthquakeDashboardScreen);
