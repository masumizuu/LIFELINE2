import React from 'react';
import * as GlobalStyles from '../GlobalStyles.js';
import ENumNBBlock from '../components/ENumNBBlock';
import Images from '../config/Images';
import Breakpoints from '../utils/Breakpoints';
import * as StyleSheet from '../utils/StyleSheet';
import useWindowDimensions from '../utils/useWindowDimensions';
import { ScreenContainer, Touchable, withTheme } from '@draftbit/ui';
import * as Linking from 'expo-linking';
import { Image, Text, View } from 'react-native';

const EmergencyNumbersScreen = props => {
  const { theme } = props;
  const dimensions = useWindowDimensions();

  return (
    <ScreenContainer hasSafeArea={false} scrollable={false}>
      {/* mainview */}
      <View
        style={StyleSheet.applyWidth(
          {
            alignItems: 'stretch',
            gap: 5,
            justifyContent: 'space-between',
            marginTop: 50,
            paddingTop: 50,
          },
          dimensions.width
        )}
      >
        {/* title12345 */}
        <Text
          accessible={true}
          {...GlobalStyles.TextStyles(theme)['Text'].props}
          style={StyleSheet.applyWidth(
            StyleSheet.compose(GlobalStyles.TextStyles(theme)['Text'].style, {
              color: theme.colors['Surface'],
              fontFamily: 'Inter_900Black',
              fontSize: 20,
              marginBottom: 20,
              textAlign: 'center',
            }),
            dimensions.width
          )}
        >
          {'EMERGENCY NUMBERS'}
        </Text>
        {/* num1 */}
        <View
          style={StyleSheet.applyWidth(
            {
              flexDirection: 'row',
              justifyContent: 'space-evenly',
              margin: 8,
              padding: 8,
            },
            dimensions.width
          )}
        >
          {/* im1 */}
          <Image
            resizeMode={'cover'}
            {...GlobalStyles.ImageStyles(theme)['Image 2'].props}
            source={Images.Imgrescue}
            style={StyleSheet.applyWidth(
              StyleSheet.compose(
                GlobalStyles.ImageStyles(theme)['Image 2'].style,
                { height: 70, width: 70 }
              ),
              dimensions.width
            )}
          />
          {/* textst */}
          <View
            style={StyleSheet.applyWidth(
              { justifyContent: 'space-evenly' },
              dimensions.width
            )}
          >
            {/* Taguig Rescue */}
            <Text
              accessible={true}
              {...GlobalStyles.TextStyles(theme)['Text'].props}
              style={StyleSheet.applyWidth(
                StyleSheet.compose(
                  GlobalStyles.TextStyles(theme)['Text'].style,
                  {
                    color: theme.colors['Surface'],
                    fontFamily: 'Inter_800ExtraBold',
                    fontSize: 17,
                    paddingBottom: 5,
                    textTransform: 'uppercase',
                  }
                ),
                dimensions.width
              )}
            >
              {'Taguig Rescue'}
            </Text>
            {/* desc */}
            <Text
              accessible={true}
              {...GlobalStyles.TextStyles(theme)['Text'].props}
              style={StyleSheet.applyWidth(
                StyleSheet.compose(
                  GlobalStyles.TextStyles(theme)['Text'].style,
                  {
                    color: theme.colors['Studily_Light_Gray_2'],
                    fontFamily: 'Inter_400Regular',
                    fontSize: 10,
                  }
                ),
                dimensions.width
              )}
            >
              {'For fires, floods, accidents, and other calamities'}
            </Text>
            {/* boop1 */}
            <Touchable
              onPress={() => {
                try {
                  Linking.openURL('');
                } catch (err) {
                  console.error(err);
                }
              }}
            >
              {/* numba */}
              <Text
                accessible={true}
                {...GlobalStyles.TextStyles(theme)['Text'].props}
                style={StyleSheet.applyWidth(
                  StyleSheet.compose(
                    GlobalStyles.TextStyles(theme)['Text'].style,
                    {
                      color: theme.colors['Secondary'],
                      fontFamily: 'Inter_600SemiBold',
                      fontSize: 19,
                      paddingTop: 5,
                      textDecorationLine: 'underline',
                    }
                  ),
                  dimensions.width
                )}
              >
                {'0919-070-3112'}
              </Text>
            </Touchable>
          </View>
        </View>
        {/* num1 2 */}
        <View
          style={StyleSheet.applyWidth(
            {
              flexDirection: 'row',
              justifyContent: 'space-evenly',
              margin: 8,
              padding: 8,
            },
            dimensions.width
          )}
        >
          {/* im1 2 */}
          <Image
            resizeMode={'cover'}
            {...GlobalStyles.ImageStyles(theme)['Image 2'].props}
            source={Images.Imgcc}
            style={StyleSheet.applyWidth(
              StyleSheet.compose(
                GlobalStyles.ImageStyles(theme)['Image 2'].style,
                { height: 70, width: 70 }
              ),
              dimensions.width
            )}
          />
          {/* textst 2 */}
          <View
            style={StyleSheet.applyWidth(
              { justifyContent: 'space-evenly' },
              dimensions.width
            )}
          >
            {/* Taguig CC */}
            <Text
              accessible={true}
              {...GlobalStyles.TextStyles(theme)['Text'].props}
              style={StyleSheet.applyWidth(
                StyleSheet.compose(
                  GlobalStyles.TextStyles(theme)['Text'].style,
                  {
                    color: theme.colors['Surface'],
                    fontFamily: 'Inter_800ExtraBold',
                    fontSize: 17,
                    paddingBottom: 5,
                    textTransform: 'uppercase',
                  }
                ),
                dimensions.width
              )}
            >
              {'Taguig Command Center'}
            </Text>
            {/* boop1 2 */}
            <Touchable>
              {/* numba 2 */}
              <Text
                accessible={true}
                {...GlobalStyles.TextStyles(theme)['Text'].props}
                style={StyleSheet.applyWidth(
                  StyleSheet.compose(
                    GlobalStyles.TextStyles(theme)['Text'].style,
                    {
                      color: theme.colors['Secondary'],
                      fontFamily: 'Inter_600SemiBold',
                      fontSize: 19,
                      textDecorationLine: 'underline',
                    }
                  ),
                  dimensions.width
                )}
              >
                {'(02) 8789-3200'}
              </Text>
            </Touchable>
          </View>
        </View>
        {/* num1 3 */}
        <View
          style={StyleSheet.applyWidth(
            {
              alignItems: 'center',
              flexDirection: 'row',
              justifyContent: 'space-evenly',
              margin: 8,
              padding: 8,
            },
            dimensions.width
          )}
        >
          {/* im1 3 */}
          <Image
            resizeMode={'cover'}
            {...GlobalStyles.ImageStyles(theme)['Image 2'].props}
            source={Images.Imgpolice}
            style={StyleSheet.applyWidth(
              StyleSheet.compose(
                GlobalStyles.ImageStyles(theme)['Image 2'].style,
                { height: 70, width: 70 }
              ),
              dimensions.width
            )}
          />
          {/* textst 3 */}
          <View
            style={StyleSheet.applyWidth(
              { justifyContent: 'space-evenly' },
              dimensions.width
            )}
          >
            {/* Taguig PNP */}
            <Text
              accessible={true}
              {...GlobalStyles.TextStyles(theme)['Text'].props}
              style={StyleSheet.applyWidth(
                StyleSheet.compose(
                  GlobalStyles.TextStyles(theme)['Text'].style,
                  {
                    color: theme.colors['Surface'],
                    fontFamily: 'Inter_800ExtraBold',
                    fontSize: 17,
                    paddingBottom: 5,
                    textTransform: 'uppercase',
                  }
                ),
                dimensions.width
              )}
            >
              {'Taguig PNP'}
            </Text>
            {/* desc2 */}
            <Text
              accessible={true}
              {...GlobalStyles.TextStyles(theme)['Text'].props}
              style={StyleSheet.applyWidth(
                StyleSheet.compose(
                  GlobalStyles.TextStyles(theme)['Text'].style,
                  {
                    color: theme.colors['Studily_Light_Gray_2'],
                    fontFamily: 'Inter_400Regular',
                    fontSize: 10,
                  }
                ),
                dimensions.width
              )}
            >
              {'For crimes and other forms of peace disturbance'}
            </Text>
            {/* boop1 3 */}
            <Touchable>
              {/* numba 3 */}
              <Text
                accessible={true}
                {...GlobalStyles.TextStyles(theme)['Text'].props}
                style={StyleSheet.applyWidth(
                  StyleSheet.compose(
                    GlobalStyles.TextStyles(theme)['Text'].style,
                    {
                      color: theme.colors['Secondary'],
                      fontFamily: 'Inter_600SemiBold',
                      fontSize: 19,
                      textDecorationLine: 'underline',
                    }
                  ),
                  dimensions.width
                )}
              >
                {'(02) 8642-3582'}
              </Text>
            </Touchable>
            {/* boop1 4 */}
            <Touchable>
              {/* numba 4 */}
              <Text
                accessible={true}
                {...GlobalStyles.TextStyles(theme)['Text'].props}
                style={StyleSheet.applyWidth(
                  StyleSheet.compose(
                    GlobalStyles.TextStyles(theme)['Text'].style,
                    {
                      color: theme.colors['Secondary'],
                      fontFamily: 'Inter_600SemiBold',
                      fontSize: 19,
                      textDecorationLine: 'underline',
                    }
                  ),
                  dimensions.width
                )}
              >
                {'0998-598-7932'}
              </Text>
            </Touchable>
          </View>
        </View>
        {/* num1 4 */}
        <View
          style={StyleSheet.applyWidth(
            {
              alignItems: 'center',
              flexDirection: 'row',
              justifyContent: 'space-evenly',
              margin: 8,
              padding: 8,
            },
            dimensions.width
          )}
        >
          {/* im1 4 */}
          <Image
            resizeMode={'cover'}
            {...GlobalStyles.ImageStyles(theme)['Image 2'].props}
            source={Images.Imgfiredept}
            style={StyleSheet.applyWidth(
              StyleSheet.compose(
                GlobalStyles.ImageStyles(theme)['Image 2'].style,
                { height: 70, width: 70 }
              ),
              dimensions.width
            )}
          />
          {/* textst 4 */}
          <View
            style={StyleSheet.applyWidth(
              { justifyContent: 'space-evenly' },
              dimensions.width
            )}
          >
            {/* Taguig BFP */}
            <Text
              accessible={true}
              {...GlobalStyles.TextStyles(theme)['Text'].props}
              style={StyleSheet.applyWidth(
                StyleSheet.compose(
                  GlobalStyles.TextStyles(theme)['Text'].style,
                  {
                    color: theme.colors['Surface'],
                    fontFamily: 'Inter_800ExtraBold',
                    fontSize: 17,
                    paddingBottom: 5,
                    textTransform: 'uppercase',
                  }
                ),
                dimensions.width
              )}
            >
              {'Taguig BFP'}
            </Text>
            {/* desc4 */}
            <Text
              accessible={true}
              {...GlobalStyles.TextStyles(theme)['Text'].props}
              style={StyleSheet.applyWidth(
                StyleSheet.compose(
                  GlobalStyles.TextStyles(theme)['Text'].style,
                  {
                    color: theme.colors['Studily_Light_Gray_2'],
                    fontFamily: 'Inter_400Regular',
                    fontSize: 10,
                  }
                ),
                dimensions.width
              )}
            >
              {'For fire prevention & protection (Landline & phone)\n'}
            </Text>
            {/* boop1 45 */}
            <Touchable
              style={StyleSheet.applyWidth(
                { marginBottom: 2 },
                dimensions.width
              )}
            >
              {/* numba 45 */}
              <Text
                accessible={true}
                {...GlobalStyles.TextStyles(theme)['Text'].props}
                style={StyleSheet.applyWidth(
                  StyleSheet.compose(
                    GlobalStyles.TextStyles(theme)['Text'].style,
                    {
                      color: theme.colors['Secondary'],
                      fontFamily: 'Inter_600SemiBold',
                      fontSize: 19,
                      textDecorationLine: 'underline',
                    }
                  ),
                  dimensions.width
                )}
              >
                {'(02) 8837-0740\n'}
              </Text>
            </Touchable>
            {/* boop1 4 */}
            <Touchable
              style={StyleSheet.applyWidth(
                { marginBottom: 2 },
                dimensions.width
              )}
            >
              {/* numba 4 */}
              <Text
                accessible={true}
                {...GlobalStyles.TextStyles(theme)['Text'].props}
                style={StyleSheet.applyWidth(
                  StyleSheet.compose(
                    GlobalStyles.TextStyles(theme)['Text'].style,
                    {
                      color: theme.colors['Secondary'],
                      fontFamily: 'Inter_600SemiBold',
                      fontSize: 19,
                      textDecorationLine: 'underline',
                    }
                  ),
                  dimensions.width
                )}
              >
                {'(02) 8837-4496'}
              </Text>
            </Touchable>
            {/* boop1 5 */}
            <Touchable>
              {/* numba 5 */}
              <Text
                accessible={true}
                {...GlobalStyles.TextStyles(theme)['Text'].props}
                style={StyleSheet.applyWidth(
                  StyleSheet.compose(
                    GlobalStyles.TextStyles(theme)['Text'].style,
                    {
                      color: theme.colors['Secondary'],
                      fontFamily: 'Inter_600SemiBold',
                      fontSize: 19,
                      textDecorationLine: 'underline',
                    }
                  ),
                  dimensions.width
                )}
              >
                {'0906-211-0919'}
              </Text>
            </Touchable>
          </View>
        </View>
      </View>
      {/* puter2 */}
      <View
        style={StyleSheet.applyWidth(
          { bottom: 0, position: 'absolute', width: '100%' },
          dimensions.width
        )}
      >
        <ENumNBBlock />
      </View>
    </ScreenContainer>
  );
};

export default withTheme(EmergencyNumbersScreen);
