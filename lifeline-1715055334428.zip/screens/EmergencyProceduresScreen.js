import React from 'react';
import * as GlobalStyles from '../GlobalStyles.js';
import EProcNBBlock from '../components/EProcNBBlock';
import Images from '../config/Images';
import Breakpoints from '../utils/Breakpoints';
import * as StyleSheet from '../utils/StyleSheet';
import useWindowDimensions from '../utils/useWindowDimensions';
import {
  ScreenContainer,
  SimpleStyleScrollView,
  Touchable,
  VStack,
  withTheme,
} from '@draftbit/ui';
import { ImageBackground, Text, View } from 'react-native';

const EmergencyProceduresScreen = props => {
  const { theme, navigation } = props;
  const dimensions = useWindowDimensions();

  return (
    <ScreenContainer
      hasSafeArea={false}
      scrollable={false}
      style={StyleSheet.applyWidth(
        { backgroundColor: theme.colors['Primary'] },
        dimensions.width
      )}
    >
      {/* Scroll Viewpl */}
      <SimpleStyleScrollView
        bounces={true}
        horizontal={false}
        keyboardShouldPersistTaps={'never'}
        nestedScrollEnabled={false}
        showsHorizontalScrollIndicator={true}
        showsVerticalScrollIndicator={true}
        style={StyleSheet.applyWidth({ marginBottom: 45 }, dimensions.width)}
      >
        {/* V Stackpl */}
        <VStack
          {...GlobalStyles.VStackStyles(theme)['V Stack'].props}
          style={StyleSheet.applyWidth(
            StyleSheet.compose(
              GlobalStyles.VStackStyles(theme)['V Stack'].style,
              {
                alignItems: 'center',
                flexDirection: null,
                gap: 10,
                justifyContent: 'space-evenly',
              }
            ),
            dimensions.width
          )}
        >
          {/* Image Card1 */}
          <Touchable
            onPress={() => {
              try {
                /* 'Navigate' action requires configuration: choose a navigation destination */
              } catch (err) {
                console.error(err);
              }
            }}
            style={StyleSheet.applyWidth(
              { height: 150, marginTop: 10, width: '100%' },
              dimensions.width
            )}
          >
            {/* Image Background1 */}
            <ImageBackground
              resizeMode={'cover'}
              source={Images.ImgDp101}
              style={StyleSheet.applyWidth(
                {
                  alignItems: 'center',
                  height: 150,
                  justifyContent: 'space-between',
                  width: '100%',
                },
                dimensions.width
              )}
            >
              {/* View 21 */}
              <View
                style={StyleSheet.applyWidth(
                  {
                    alignContent: 'stretch',
                    alignItems: 'center',
                    alignSelf: 'center',
                    flex: 50,
                    flexDirection: 'column',
                    height: 120,
                    justifyContent: 'center',
                    margin: 16,
                    width: '90%',
                  },
                  dimensions.width
                )}
              >
                {/* Text1 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text'].props}
                  adjustsFontSizeToFit={true}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text'].style,
                      {
                        alignSelf: 'center',
                        color: theme.colors['Surface'],
                        fontFamily: 'Inter_700Bold',
                        fontSize: 16,
                        textAlign: 'center',
                      }
                    ),
                    dimensions.width
                  )}
                >
                  {'DISASTER PREPAREDNESS 101'}
                </Text>
              </View>
            </ImageBackground>
          </Touchable>
          {/* Image Card 22 */}
          <Touchable
            style={StyleSheet.applyWidth(
              { height: 150, width: '100%' },
              dimensions.width
            )}
          >
            {/* Image Background2 */}
            <ImageBackground
              resizeMode={'cover'}
              source={Images.Eq}
              style={StyleSheet.applyWidth(
                {
                  alignItems: 'center',
                  height: 150,
                  justifyContent: 'space-between',
                  width: '100%',
                },
                dimensions.width
              )}
            >
              {/* View 22 */}
              <View
                style={StyleSheet.applyWidth(
                  {
                    alignContent: 'stretch',
                    alignItems: 'center',
                    alignSelf: 'center',
                    flex: 50,
                    flexDirection: 'column',
                    height: 120,
                    justifyContent: 'center',
                    margin: 16,
                    width: '90%',
                  },
                  dimensions.width
                )}
              >
                {/* Text2 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text'].props}
                  adjustsFontSizeToFit={true}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text'].style,
                      {
                        alignSelf: 'center',
                        color: theme.colors['Surface'],
                        fontFamily: 'Inter_700Bold',
                        fontSize: 16,
                        textAlign: 'center',
                      }
                    ),
                    dimensions.width
                  )}
                >
                  {'EARTHQUAKES'}
                </Text>
              </View>
            </ImageBackground>
          </Touchable>
          {/* imgcard33 */}
          <Touchable
            style={StyleSheet.applyWidth(
              { height: 150, width: '100%' },
              dimensions.width
            )}
          >
            {/* Image Background33 */}
            <ImageBackground
              resizeMode={'cover'}
              source={Images.Storms}
              style={StyleSheet.applyWidth(
                {
                  alignItems: 'center',
                  height: 150,
                  justifyContent: 'space-between',
                  width: '100%',
                },
                dimensions.width
              )}
            >
              {/* View 23 */}
              <View
                style={StyleSheet.applyWidth(
                  {
                    alignContent: 'stretch',
                    alignItems: 'center',
                    alignSelf: 'center',
                    flex: 50,
                    flexDirection: 'column',
                    height: 120,
                    justifyContent: 'center',
                    margin: 16,
                    width: '90%',
                  },
                  dimensions.width
                )}
              >
                {/* Text3 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text'].props}
                  adjustsFontSizeToFit={true}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text'].style,
                      {
                        alignSelf: 'center',
                        color: theme.colors['Surface'],
                        fontFamily: 'Inter_700Bold',
                        fontSize: 16,
                        textAlign: 'center',
                      }
                    ),
                    dimensions.width
                  )}
                >
                  {'STORMS'}
                </Text>
              </View>
            </ImageBackground>
          </Touchable>
          {/* Image Card 44 */}
          <Touchable
            style={StyleSheet.applyWidth(
              { height: 150, width: '100%' },
              dimensions.width
            )}
          >
            {/* Image Background4 */}
            <ImageBackground
              resizeMode={'cover'}
              source={Images.Floods}
              style={StyleSheet.applyWidth(
                {
                  alignItems: 'center',
                  height: 150,
                  justifyContent: 'space-between',
                  width: '100%',
                },
                dimensions.width
              )}
            >
              {/* View 24 */}
              <View
                style={StyleSheet.applyWidth(
                  {
                    alignContent: 'stretch',
                    alignItems: 'center',
                    alignSelf: 'center',
                    flex: 50,
                    flexDirection: 'column',
                    height: 120,
                    justifyContent: 'center',
                    margin: 16,
                    width: '90%',
                  },
                  dimensions.width
                )}
              >
                {/* Text4 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text'].props}
                  adjustsFontSizeToFit={true}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text'].style,
                      {
                        alignSelf: 'center',
                        color: theme.colors['Surface'],
                        fontFamily: 'Inter_700Bold',
                        fontSize: 16,
                        textAlign: 'center',
                      }
                    ),
                    dimensions.width
                  )}
                >
                  {'FLOODS'}
                </Text>
              </View>
            </ImageBackground>
          </Touchable>
          {/* Image Card 55 */}
          <Touchable
            style={StyleSheet.applyWidth(
              { height: 150, width: '100%' },
              dimensions.width
            )}
          >
            {/* Image Background5 */}
            <ImageBackground
              resizeMode={'cover'}
              source={Images.Tsunami}
              style={StyleSheet.applyWidth(
                {
                  alignItems: 'center',
                  height: 150,
                  justifyContent: 'space-between',
                  width: '100%',
                },
                dimensions.width
              )}
            >
              {/* View 25 */}
              <View
                style={StyleSheet.applyWidth(
                  {
                    alignContent: 'stretch',
                    alignItems: 'center',
                    alignSelf: 'center',
                    flex: 50,
                    flexDirection: 'column',
                    height: 120,
                    justifyContent: 'center',
                    margin: 16,
                    width: '90%',
                  },
                  dimensions.width
                )}
              >
                {/* Text5 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text'].props}
                  adjustsFontSizeToFit={true}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text'].style,
                      {
                        alignSelf: 'center',
                        color: theme.colors['Surface'],
                        fontFamily: 'Inter_700Bold',
                        fontSize: 16,
                        textAlign: 'center',
                      }
                    ),
                    dimensions.width
                  )}
                >
                  {'TSUNAMIS'}
                </Text>
              </View>
            </ImageBackground>
          </Touchable>
          {/* Image Card 66 */}
          <Touchable
            style={StyleSheet.applyWidth(
              { height: 150, marginBottom: 10, width: '100%' },
              dimensions.width
            )}
          >
            {/* Image Background6 */}
            <ImageBackground
              resizeMode={'cover'}
              source={Images.Mit}
              style={StyleSheet.applyWidth(
                {
                  alignItems: 'center',
                  height: 150,
                  justifyContent: 'space-between',
                  width: '100%',
                },
                dimensions.width
              )}
            >
              {/* View 26 */}
              <View
                style={StyleSheet.applyWidth(
                  {
                    alignContent: 'stretch',
                    alignItems: 'center',
                    alignSelf: 'center',
                    flex: 50,
                    flexDirection: 'column',
                    height: 120,
                    justifyContent: 'center',
                    margin: 16,
                    width: '90%',
                  },
                  dimensions.width
                )}
              >
                {/* Text6 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text'].props}
                  adjustsFontSizeToFit={true}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text'].style,
                      {
                        alignSelf: 'center',
                        color: theme.colors['Surface'],
                        fontFamily: 'Inter_700Bold',
                        fontSize: 16,
                        textAlign: 'center',
                      }
                    ),
                    dimensions.width
                  )}
                >
                  {'MITIGATION'}
                </Text>
              </View>
            </ImageBackground>
          </Touchable>
        </VStack>
      </SimpleStyleScrollView>
      {/* Viewto */}
      <View
        style={StyleSheet.applyWidth(
          { bottom: 0, marginTop: 10, position: 'absolute', width: '100%' },
          dimensions.width
        )}
      >
        <EProcNBBlock />
      </View>
    </ScreenContainer>
  );
};

export default withTheme(EmergencyProceduresScreen);
