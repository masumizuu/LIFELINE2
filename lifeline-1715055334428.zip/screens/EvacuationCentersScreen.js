import React from 'react';
import * as GlobalStyles from '../GlobalStyles.js';
import DivBlock from '../components/DivBlock';
import EvacNBBlock from '../components/EvacNBBlock';
import Breakpoints from '../utils/Breakpoints';
import * as StyleSheet from '../utils/StyleSheet';
import useWindowDimensions from '../utils/useWindowDimensions';
import {
  AccordionGroup,
  ScreenContainer,
  SimpleStyleScrollView,
  Touchable,
  VStack,
  withTheme,
} from '@draftbit/ui';
import { Text, View } from 'react-native';

const EvacuationCentersScreen = props => {
  const { theme } = props;
  const dimensions = useWindowDimensions();

  return (
    <ScreenContainer
      hasSafeArea={false}
      scrollable={false}
      hasBottomSafeArea={false}
      style={StyleSheet.applyWidth(
        { backgroundColor: theme.colors['Primary'] },
        dimensions.width
      )}
    >
      <SimpleStyleScrollView
        bounces={true}
        horizontal={false}
        keyboardShouldPersistTaps={'never'}
        nestedScrollEnabled={false}
        showsHorizontalScrollIndicator={true}
        showsVerticalScrollIndicator={true}
        refreshColor={theme.colors['Secondary']}
        style={StyleSheet.applyWidth(
          { marginBottom: 60, marginLeft: 10, marginRight: 10 },
          dimensions.width
        )}
      >
        <VStack
          {...GlobalStyles.VStackStyles(theme)['V Stack'].props}
          style={StyleSheet.applyWidth(
            StyleSheet.compose(
              GlobalStyles.VStackStyles(theme)['V Stack'].style,
              { marginTop: 10 }
            ),
            dimensions.width
          )}
        >
          {/* Bagumbayan */}
          <AccordionGroup
            caretSize={24}
            expanded={false}
            iconSize={24}
            {...GlobalStyles.AccordionGroupStyles(theme)['Accordion'].props}
            caretColor={theme.colors['Secondary']}
            closedColor={theme.colors['Secondary']}
            label={'Bagumbayan'}
            openColor={theme.colors['Surface']}
            style={StyleSheet.applyWidth(
              StyleSheet.compose(
                GlobalStyles.AccordionGroupStyles(theme)['Accordion'].style,
                {
                  backgroundColor: theme.colors['Primary'],
                  fontFamily: 'Inter_500Medium',
                  margin: 4,
                  padding: 8,
                  paddingBottom: null,
                  paddingLeft: null,
                  paddingRight: null,
                  paddingTop: null,
                }
              ),
              dimensions.width
            )}
          >
            {/* bag1 */}
            <Touchable>
              {/* bag2 */}
              <View
                style={StyleSheet.applyWidth(
                  { backgroundColor: theme.colors['Primary'], margin: 8 },
                  dimensions.width
                )}
              >
                {/* bag3 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text'].style,
                      { color: theme.colors['Surface'], marginLeft: 15 }
                    ),
                    dimensions.width
                  )}
                >
                  {'Cayetano Sports Complex'}
                </Text>
                {/* bag4 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text 2'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text 2'].style,
                      {
                        color: theme.colors['Studily_Light_Gray_2'],
                        marginLeft: 20,
                      }
                    ),
                    dimensions.width
                  )}
                >
                  {'Dir. A. Bunye, Taguig, Kalakhang Maynila'}
                </Text>
              </View>
            </Touchable>
            {/* bag5 */}
            <Touchable>
              {/* bag6 */}
              <View
                style={StyleSheet.applyWidth(
                  {
                    backgroundColor: theme.colors['Primary'],
                    marginLeft: 8,
                    marginRight: 8,
                  },
                  dimensions.width
                )}
              >
                {/* bag7 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text'].style,
                      { color: theme.colors['Surface'], marginLeft: 15 }
                    ),
                    dimensions.width
                  )}
                >
                  {'Rockyside Community Center'}
                </Text>
                {/* bag8 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text 2'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text 2'].style,
                      {
                        color: theme.colors['Studily_Light_Gray_2'],
                        marginLeft: 20,
                      }
                    ),
                    dimensions.width
                  )}
                >
                  {'Rockyside Village, Taguig, Metro Manila'}
                </Text>
              </View>
            </Touchable>
            {/* bag9 */}
            <Touchable>
              {/* bag10 */}
              <View
                style={StyleSheet.applyWidth(
                  { backgroundColor: theme.colors['Primary'], margin: 8 },
                  dimensions.width
                )}
              >
                {/* bag11 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text'].style,
                      { color: theme.colors['Surface'], marginLeft: 15 }
                    ),
                    dimensions.width
                  )}
                >
                  {'Cipriano P. Sta. Teresa Elementary School'}
                </Text>
                {/* bag12 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text 2'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text 2'].style,
                      {
                        color: theme.colors['Studily_Light_Gray_2'],
                        marginLeft: 20,
                      }
                    ),
                    dimensions.width
                  )}
                >
                  {'1631, M. L. Quezon St, Taguig, Metro Manila'}
                </Text>
              </View>
            </Touchable>
          </AccordionGroup>
          <DivBlock />
          {/* Bambang */}
          <AccordionGroup
            caretSize={24}
            expanded={false}
            iconSize={24}
            {...GlobalStyles.AccordionGroupStyles(theme)['Accordion'].props}
            caretColor={theme.colors['Secondary']}
            closedColor={theme.colors['Secondary']}
            label={'Bambang'}
            openColor={theme.colors['Surface']}
            style={StyleSheet.applyWidth(
              StyleSheet.compose(
                GlobalStyles.AccordionGroupStyles(theme)['Accordion'].style,
                {
                  backgroundColor: theme.colors['Primary'],
                  borderColor: theme.colors['Surface'],
                  borderRadius: 10,
                  borderStyle: 'solid',
                  fontFamily: 'Inter_500Medium',
                  margin: 4,
                  padding: 8,
                  paddingBottom: null,
                  paddingLeft: null,
                  paddingRight: null,
                  paddingTop: null,
                }
              ),
              dimensions.width
            )}
          >
            {/* bam1 */}
            <Touchable>
              {/* bam2 */}
              <View
                style={StyleSheet.applyWidth({ margin: 8 }, dimensions.width)}
              >
                {/* bam3 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text'].style,
                      { color: theme.colors['Surface'], marginLeft: 15 }
                    ),
                    dimensions.width
                  )}
                >
                  {'Taguig Integrated School '}
                </Text>
                {/* bam4 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text 2'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text 2'].style,
                      {
                        color: theme.colors['Studily_Light_Gray_2'],
                        marginLeft: 20,
                      }
                    ),
                    dimensions.width
                  )}
                >
                  {'Liwayway, Taguig, 1637 Metro Manila'}
                </Text>
              </View>
            </Touchable>
          </AccordionGroup>
          <DivBlock />
          {/* Calzada-Tipas */}
          <AccordionGroup
            caretSize={24}
            expanded={false}
            iconSize={24}
            {...GlobalStyles.AccordionGroupStyles(theme)['Accordion'].props}
            caretColor={theme.colors['Secondary']}
            closedColor={theme.colors['Secondary']}
            label={'Calzada-Tipas'}
            openColor={theme.colors['Surface']}
            style={StyleSheet.applyWidth(
              StyleSheet.compose(
                GlobalStyles.AccordionGroupStyles(theme)['Accordion'].style,
                {
                  borderColor: theme.colors['Surface'],
                  borderStyle: 'solid',
                  fontFamily: 'Inter_500Medium',
                }
              ),
              dimensions.width
            )}
          >
            {/* ct1 */}
            <Touchable>
              {/* ct2 */}
              <View
                style={StyleSheet.applyWidth({ margin: 8 }, dimensions.width)}
              >
                {/* ct3 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text'].style,
                      { color: theme.colors['Surface'], marginLeft: 15 }
                    ),
                    dimensions.width
                  )}
                >
                  {'Tipas Elementary School Annex'}
                </Text>
                {/* ct4 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text 2'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text 2'].style,
                      {
                        color: theme.colors['Studily_Light_Gray_2'],
                        marginLeft: 20,
                      }
                    ),
                    dimensions.width
                  )}
                >
                  {'Sta. Barbara, Calzada Tipas, Taguig, 1637 Metro Manila'}
                </Text>
              </View>
            </Touchable>
          </AccordionGroup>
          <DivBlock />
          {/* Central Bicutan */}
          <AccordionGroup
            caretSize={24}
            expanded={false}
            iconSize={24}
            {...GlobalStyles.AccordionGroupStyles(theme)['Accordion'].props}
            caretColor={theme.colors['Secondary']}
            closedColor={theme.colors['Secondary']}
            label={'Central Bicutan'}
            openColor={theme.colors['Surface']}
            style={StyleSheet.applyWidth(
              StyleSheet.compose(
                GlobalStyles.AccordionGroupStyles(theme)['Accordion'].style,
                {
                  borderColor: theme.colors['Surface'],
                  borderStyle: 'solid',
                  fontFamily: 'Inter_500Medium',
                }
              ),
              dimensions.width
            )}
          >
            {/* cb1 */}
            <Touchable>
              {/* cb2 */}
              <View
                style={StyleSheet.applyWidth({ margin: 8 }, dimensions.width)}
              >
                {/* cb3 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text'].style,
                      { color: theme.colors['Surface'], marginLeft: 15 }
                    ),
                    dimensions.width
                  )}
                >
                  {'Central Bicutan Covered Court'}
                </Text>
                {/* cb4 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text 2'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text 2'].style,
                      {
                        color: theme.colors['Studily_Light_Gray_2'],
                        marginLeft: 20,
                      }
                    ),
                    dimensions.width
                  )}
                >
                  {
                    'Blk 163 Lot 2 Central Bicutan Taguig City, Taguig, Philippines'
                  }
                </Text>
              </View>
            </Touchable>
          </AccordionGroup>
          <DivBlock />
          {/* Central Signal Village */}
          <AccordionGroup
            caretSize={24}
            expanded={false}
            iconSize={24}
            {...GlobalStyles.AccordionGroupStyles(theme)['Accordion'].props}
            caretColor={theme.colors['Secondary']}
            closedColor={theme.colors['Secondary']}
            label={'Central Signal Village'}
            openColor={theme.colors['Surface']}
            style={StyleSheet.applyWidth(
              StyleSheet.compose(
                GlobalStyles.AccordionGroupStyles(theme)['Accordion'].style,
                {
                  borderColor: theme.colors['Surface'],
                  borderStyle: 'solid',
                  fontFamily: 'Inter_500Medium',
                }
              ),
              dimensions.width
            )}
          >
            {/* csv1 */}
            <Touchable>
              {/* csv2 */}
              <View
                style={StyleSheet.applyWidth({ margin: 8 }, dimensions.width)}
              >
                {/* csv3 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text'].style,
                      { color: theme.colors['Surface'], marginLeft: 15 }
                    ),
                    dimensions.width
                  )}
                >
                  {"EM's Signal Village Elementary School"}
                </Text>
                {/* csv4 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text 2'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text 2'].style,
                      {
                        color: theme.colors['Studily_Light_Gray_2'],
                        marginLeft: 20,
                      }
                    ),
                    dimensions.width
                  )}
                >
                  {'Miranda, Taguig, 1630 Metro Manila'}
                </Text>
              </View>
            </Touchable>
          </AccordionGroup>
          <DivBlock />
          {/* Fort Bonifacio */}
          <AccordionGroup
            caretSize={24}
            expanded={false}
            iconSize={24}
            {...GlobalStyles.AccordionGroupStyles(theme)['Accordion'].props}
            caretColor={theme.colors['Secondary']}
            closedColor={theme.colors['Secondary']}
            label={'Fort Bonifacio'}
            openColor={theme.colors['Surface']}
            style={StyleSheet.applyWidth(
              StyleSheet.compose(
                GlobalStyles.AccordionGroupStyles(theme)['Accordion'].style,
                {
                  borderColor: theme.colors['Surface'],
                  borderStyle: 'solid',
                  fontFamily: 'Inter_500Medium',
                }
              ),
              dimensions.width
            )}
          >
            {/* fb1 */}
            <Touchable>
              {/* fb2 */}
              <View
                style={StyleSheet.applyWidth({ margin: 8 }, dimensions.width)}
              >
                {/* fb3 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text'].style,
                      { color: theme.colors['Surface'], marginLeft: 15 }
                    ),
                    dimensions.width
                  )}
                >
                  {'Gat Andres Bonifacio Elementary School'}
                </Text>
                {/* fb4 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text 2'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text 2'].style,
                      {
                        color: theme.colors['Studily_Light_Gray_2'],
                        marginLeft: 20,
                      }
                    ),
                    dimensions.width
                  )}
                >
                  {'Zone 3 Chino Roces Ave, Taguig, 1201 Metro Manila'}
                </Text>
              </View>
            </Touchable>
          </AccordionGroup>
          <DivBlock />
          {/* Hagonoy */}
          <AccordionGroup
            caretSize={24}
            expanded={false}
            iconSize={24}
            {...GlobalStyles.AccordionGroupStyles(theme)['Accordion'].props}
            caretColor={theme.colors['Secondary']}
            closedColor={theme.colors['Secondary']}
            label={'Hagonoy'}
            openColor={theme.colors['Surface']}
            style={StyleSheet.applyWidth(
              StyleSheet.compose(
                GlobalStyles.AccordionGroupStyles(theme)['Accordion'].style,
                {
                  borderColor: theme.colors['Surface'],
                  borderStyle: 'solid',
                  fontFamily: 'Inter_500Medium',
                }
              ),
              dimensions.width
            )}
          >
            {/* hg1 */}
            <Touchable>
              {/* hg2 */}
              <View
                style={StyleSheet.applyWidth({ margin: 8 }, dimensions.width)}
              >
                {/* hg3 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text'].style,
                      { color: theme.colors['Surface'], marginLeft: 15 }
                    ),
                    dimensions.width
                  )}
                >
                  {'Hagonoy Sports Complex'}
                </Text>
                {/* hg4 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text 2'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text 2'].style,
                      {
                        color: theme.colors['Studily_Light_Gray_2'],
                        marginLeft: 20,
                      }
                    ),
                    dimensions.width
                  )}
                >
                  {'Capistrano St, Taguig, Metro Manila'}
                </Text>
              </View>
            </Touchable>
          </AccordionGroup>
          <DivBlock />
          {/* Ibayo-Tipas */}
          <AccordionGroup
            caretSize={24}
            expanded={false}
            iconSize={24}
            {...GlobalStyles.AccordionGroupStyles(theme)['Accordion'].props}
            caretColor={theme.colors['Secondary']}
            closedColor={theme.colors['Secondary']}
            label={'Ibayo-Tipas'}
            openColor={theme.colors['Surface']}
            style={StyleSheet.applyWidth(
              StyleSheet.compose(
                GlobalStyles.AccordionGroupStyles(theme)['Accordion'].style,
                {
                  borderColor: theme.colors['Surface'],
                  borderStyle: 'solid',
                  fontFamily: 'Inter_500Medium',
                }
              ),
              dimensions.width
            )}
          >
            {/* it1 */}
            <Touchable>
              {/* it2 */}
              <View
                style={StyleSheet.applyWidth({ margin: 8 }, dimensions.width)}
              >
                {/* it3 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text'].style,
                      { color: theme.colors['Surface'], marginLeft: 15 }
                    ),
                    dimensions.width
                  )}
                >
                  {'Tipas National High School Annex'}
                </Text>
                {/* it4 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text 2'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text 2'].style,
                      {
                        color: theme.colors['Studily_Light_Gray_2'],
                        marginLeft: 20,
                      }
                    ),
                    dimensions.width
                  )}
                >
                  {'Katurian Rd, Taguig, Metro Manila'}
                </Text>
              </View>
            </Touchable>
          </AccordionGroup>
          <DivBlock />
          {/* Katuparan */}
          <AccordionGroup
            caretSize={24}
            expanded={false}
            iconSize={24}
            {...GlobalStyles.AccordionGroupStyles(theme)['Accordion'].props}
            caretColor={theme.colors['Secondary']}
            closedColor={theme.colors['Secondary']}
            label={'Katuparan'}
            openColor={theme.colors['Surface']}
            style={StyleSheet.applyWidth(
              StyleSheet.compose(
                GlobalStyles.AccordionGroupStyles(theme)['Accordion'].style,
                {
                  borderColor: theme.colors['Surface'],
                  borderStyle: 'solid',
                  fontFamily: 'Inter_500Medium',
                }
              ),
              dimensions.width
            )}
          >
            {/* kt1 */}
            <Touchable>
              {/* kt2 */}
              <View
                style={StyleSheet.applyWidth({ margin: 8 }, dimensions.width)}
              >
                {/* kt3 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text'].style,
                      { color: theme.colors['Surface'], marginLeft: 15 }
                    ),
                    dimensions.width
                  )}
                >
                  {'Diosdado Macapagal High School'}
                </Text>
                {/* kt4 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text 2'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text 2'].style,
                      {
                        color: theme.colors['Studily_Light_Gray_2'],
                        marginLeft: 20,
                      }
                    ),
                    dimensions.width
                  )}
                >
                  {'8th, Taguig, 1630 Metro Manila'}
                </Text>
              </View>
            </Touchable>
          </AccordionGroup>
          <DivBlock />
          {/* Ligid-Tipas */}
          <AccordionGroup
            caretSize={24}
            expanded={false}
            iconSize={24}
            {...GlobalStyles.AccordionGroupStyles(theme)['Accordion'].props}
            caretColor={theme.colors['Secondary']}
            closedColor={theme.colors['Secondary']}
            label={'Ligid-Tipas'}
            openColor={theme.colors['Surface']}
            style={StyleSheet.applyWidth(
              StyleSheet.compose(
                GlobalStyles.AccordionGroupStyles(theme)['Accordion'].style,
                {
                  borderColor: theme.colors['Surface'],
                  borderStyle: 'solid',
                  fontFamily: 'Inter_500Medium',
                }
              ),
              dimensions.width
            )}
          >
            {/* lt1 */}
            <Touchable>
              {/* lt2 */}
              <View
                style={StyleSheet.applyWidth({ margin: 8 }, dimensions.width)}
              >
                {/* lt3 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text'].style,
                      { color: theme.colors['Surface'], marginLeft: 15 }
                    ),
                    dimensions.width
                  )}
                >
                  {'Barangay Hall'}
                </Text>
                {/* lt4 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text 2'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text 2'].style,
                      {
                        color: theme.colors['Studily_Light_Gray_2'],
                        marginLeft: 20,
                      }
                    ),
                    dimensions.width
                  )}
                >
                  {'80 L.Labao, Taguig, Metro Manila'}
                </Text>
              </View>
            </Touchable>
          </AccordionGroup>
          <DivBlock />
          {/* Lower Bicutan */}
          <AccordionGroup
            caretSize={24}
            expanded={false}
            iconSize={24}
            {...GlobalStyles.AccordionGroupStyles(theme)['Accordion'].props}
            caretColor={theme.colors['Secondary']}
            closedColor={theme.colors['Secondary']}
            label={'Lower Bicutan'}
            openColor={theme.colors['Surface']}
            style={StyleSheet.applyWidth(
              StyleSheet.compose(
                GlobalStyles.AccordionGroupStyles(theme)['Accordion'].style,
                {
                  borderColor: theme.colors['Surface'],
                  borderStyle: 'solid',
                  fontFamily: 'Inter_500Medium',
                }
              ),
              dimensions.width
            )}
          >
            {/* lb1 */}
            <Touchable>
              {/* lb2 */}
              <View
                style={StyleSheet.applyWidth({ margin: 8 }, dimensions.width)}
              >
                {/* lb3 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text'].style,
                      { color: theme.colors['Surface'], marginLeft: 15 }
                    ),
                    dimensions.width
                  )}
                >
                  {'Ricardo P. Cruz Sr. Elementary School'}
                </Text>
                {/* lb4 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text 2'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text 2'].style,
                      {
                        color: theme.colors['Studily_Light_Gray_2'],
                        marginLeft: 20,
                      }
                    ),
                    dimensions.width
                  )}
                >
                  {'Taguig, Manila, Metro Manila'}
                </Text>
              </View>
            </Touchable>
          </AccordionGroup>
          <DivBlock />
          {/* Maharlika Village */}
          <AccordionGroup
            caretSize={24}
            expanded={false}
            iconSize={24}
            {...GlobalStyles.AccordionGroupStyles(theme)['Accordion'].props}
            caretColor={theme.colors['Secondary']}
            closedColor={theme.colors['Secondary']}
            label={'Maharlika Village'}
            openColor={theme.colors['Surface']}
            style={StyleSheet.applyWidth(
              StyleSheet.compose(
                GlobalStyles.AccordionGroupStyles(theme)['Accordion'].style,
                {
                  borderColor: theme.colors['Surface'],
                  borderStyle: 'solid',
                  fontFamily: 'Inter_500Medium',
                }
              ),
              dimensions.width
            )}
          >
            {/* mv1 */}
            <Touchable>
              {/* mv2 */}
              <View
                style={StyleSheet.applyWidth({ margin: 8 }, dimensions.width)}
              >
                {/* mv3 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text'].style,
                      { color: theme.colors['Surface'], marginLeft: 15 }
                    ),
                    dimensions.width
                  )}
                >
                  {'Maharlika Trade Center'}
                </Text>
                {/* mv4 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text 2'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text 2'].style,
                      {
                        color: theme.colors['Studily_Light_Gray_2'],
                        marginLeft: 20,
                      }
                    ),
                    dimensions.width
                  )}
                >
                  {'Mindanao Ave, Taguig, Metro Manila'}
                </Text>
              </View>
            </Touchable>
          </AccordionGroup>
          <DivBlock />
          {/* Napindan */}
          <AccordionGroup
            caretSize={24}
            expanded={false}
            iconSize={24}
            {...GlobalStyles.AccordionGroupStyles(theme)['Accordion'].props}
            caretColor={theme.colors['Secondary']}
            closedColor={theme.colors['Secondary']}
            label={'Napindan'}
            openColor={theme.colors['Surface']}
            style={StyleSheet.applyWidth(
              StyleSheet.compose(
                GlobalStyles.AccordionGroupStyles(theme)['Accordion'].style,
                {
                  borderColor: theme.colors['Surface'],
                  borderStyle: 'solid',
                  fontFamily: 'Inter_500Medium',
                }
              ),
              dimensions.width
            )}
          >
            {/* np1 */}
            <Touchable>
              {/* np2 */}
              <View
                style={StyleSheet.applyWidth({ margin: 8 }, dimensions.width)}
              >
                {/* np3 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text'].style,
                      { color: theme.colors['Surface'], marginLeft: 15 }
                    ),
                    dimensions.width
                  )}
                >
                  {'Napindan Integrated School'}
                </Text>
                {/* np4 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text 2'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text 2'].style,
                      {
                        color: theme.colors['Studily_Light_Gray_2'],
                        marginLeft: 20,
                      }
                    ),
                    dimensions.width
                  )}
                >
                  {'114 Labao, Taguig, 1630 Metro Manila'}
                </Text>
              </View>
            </Touchable>
          </AccordionGroup>
          <DivBlock />
          {/* New Lower Bicutan */}
          <AccordionGroup
            caretSize={24}
            expanded={false}
            iconSize={24}
            {...GlobalStyles.AccordionGroupStyles(theme)['Accordion'].props}
            caretColor={theme.colors['Secondary']}
            closedColor={theme.colors['Secondary']}
            label={'New Lower Bicutan'}
            openColor={theme.colors['Surface']}
            style={StyleSheet.applyWidth(
              StyleSheet.compose(
                GlobalStyles.AccordionGroupStyles(theme)['Accordion'].style,
                {
                  borderColor: theme.colors['Surface'],
                  borderStyle: 'solid',
                  fontFamily: 'Inter_500Medium',
                }
              ),
              dimensions.width
            )}
          >
            {/* nlb1 */}
            <Touchable>
              {/* nlb2 */}
              <View
                style={StyleSheet.applyWidth({ margin: 8 }, dimensions.width)}
              >
                {/* nlb3 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text'].style,
                      { color: theme.colors['Surface'], marginLeft: 15 }
                    ),
                    dimensions.width
                  )}
                >
                  {'Ricardo P. Cruz Sr. Elementary School'}
                </Text>
                {/* nlb4 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text 2'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text 2'].style,
                      {
                        color: theme.colors['Studily_Light_Gray_2'],
                        marginLeft: 20,
                      }
                    ),
                    dimensions.width
                  )}
                >
                  {'Taguig, Manila, Metro Manila'}
                </Text>
              </View>
            </Touchable>
          </AccordionGroup>
          <DivBlock />
          {/* North Daang Hari */}
          <AccordionGroup
            caretSize={24}
            expanded={false}
            iconSize={24}
            {...GlobalStyles.AccordionGroupStyles(theme)['Accordion'].props}
            caretColor={theme.colors['Secondary']}
            closedColor={theme.colors['Secondary']}
            label={'North Daang Hari'}
            openColor={theme.colors['Surface']}
            style={StyleSheet.applyWidth(
              StyleSheet.compose(
                GlobalStyles.AccordionGroupStyles(theme)['Accordion'].style,
                {
                  borderColor: theme.colors['Surface'],
                  borderStyle: 'solid',
                  fontFamily: 'Inter_500Medium',
                }
              ),
              dimensions.width
            )}
          >
            {/* ndh1 */}
            <Touchable>
              {/* ndh2 */}
              <View
                style={StyleSheet.applyWidth({ margin: 8 }, dimensions.width)}
              >
                {/* ndh3 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text'].style,
                      { color: theme.colors['Surface'], marginLeft: 15 }
                    ),
                    dimensions.width
                  )}
                >
                  {'Daang Hari Elementary School'}
                </Text>
                {/* ndh4 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text 2'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text 2'].style,
                      {
                        color: theme.colors['Studily_Light_Gray_2'],
                        marginLeft: 20,
                      }
                    ),
                    dimensions.width
                  )}
                >
                  {'Brgy, Taguig, Kalakhang Maynila'}
                </Text>
              </View>
            </Touchable>
          </AccordionGroup>
          <DivBlock />
          {/* North Signal Village */}
          <AccordionGroup
            caretSize={24}
            expanded={false}
            iconSize={24}
            {...GlobalStyles.AccordionGroupStyles(theme)['Accordion'].props}
            caretColor={theme.colors['Secondary']}
            closedColor={theme.colors['Secondary']}
            label={'North Signal Village'}
            openColor={theme.colors['Surface']}
            style={StyleSheet.applyWidth(
              StyleSheet.compose(
                GlobalStyles.AccordionGroupStyles(theme)['Accordion'].style,
                {
                  borderColor: theme.colors['Surface'],
                  borderStyle: 'solid',
                  fontFamily: 'Inter_500Medium',
                }
              ),
              dimensions.width
            )}
          >
            {/* nsv1 */}
            <Touchable>
              {/* nsv2 */}
              <View
                style={StyleSheet.applyWidth({ margin: 8 }, dimensions.width)}
              >
                {/* nsv3 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text'].style,
                      { color: theme.colors['Surface'], marginLeft: 15 }
                    ),
                    dimensions.width
                  )}
                >
                  {'Plaza Diez - Durian Court'}
                </Text>
                {/* nsv4 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text 2'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text 2'].style,
                      {
                        color: theme.colors['Studily_Light_Gray_2'],
                        marginLeft: 20,
                      }
                    ),
                    dimensions.width
                  )}
                >
                  {'Durian St, Taguig, Metro Manila'}
                </Text>
              </View>
            </Touchable>
          </AccordionGroup>
          <DivBlock />
          {/* Palingon-Tipas */}
          <AccordionGroup
            caretSize={24}
            expanded={false}
            iconSize={24}
            {...GlobalStyles.AccordionGroupStyles(theme)['Accordion'].props}
            caretColor={theme.colors['Secondary']}
            closedColor={theme.colors['Secondary']}
            label={'Palingon-Tipas'}
            openColor={theme.colors['Surface']}
            style={StyleSheet.applyWidth(
              StyleSheet.compose(
                GlobalStyles.AccordionGroupStyles(theme)['Accordion'].style,
                {
                  borderColor: theme.colors['Surface'],
                  borderStyle: 'solid',
                  fontFamily: 'Inter_500Medium',
                }
              ),
              dimensions.width
            )}
          >
            {/* pt1 */}
            <Touchable>
              {/* pt2 */}
              <View
                style={StyleSheet.applyWidth({ margin: 8 }, dimensions.width)}
              >
                {/* pt3 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text'].style,
                      { color: theme.colors['Surface'], marginLeft: 15 }
                    ),
                    dimensions.width
                  )}
                >
                  {'Tipas Elementary School'}
                </Text>
                {/* pt4 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text 2'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text 2'].style,
                      {
                        color: theme.colors['Studily_Light_Gray_2'],
                        marginLeft: 20,
                      }
                    ),
                    dimensions.width
                  )}
                >
                  {'F.Manalo, Tipas, Taguig, 1630 Metro Manila'}
                </Text>
              </View>
            </Touchable>
          </AccordionGroup>
          <DivBlock />
          {/* Pinagsama */}
          <AccordionGroup
            caretSize={24}
            expanded={false}
            iconSize={24}
            {...GlobalStyles.AccordionGroupStyles(theme)['Accordion'].props}
            caretColor={theme.colors['Secondary']}
            closedColor={theme.colors['Secondary']}
            label={'Pinagsama'}
            openColor={theme.colors['Surface']}
            style={StyleSheet.applyWidth(
              StyleSheet.compose(
                GlobalStyles.AccordionGroupStyles(theme)['Accordion'].style,
                {
                  borderColor: theme.colors['Surface'],
                  borderStyle: 'solid',
                  fontFamily: 'Inter_500Medium',
                }
              ),
              dimensions.width
            )}
          >
            {/* pn1 */}
            <Touchable>
              {/* pn2 */}
              <View
                style={StyleSheet.applyWidth({ margin: 8 }, dimensions.width)}
              >
                {/* pn3 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text'].style,
                      { color: theme.colors['Surface'], marginLeft: 15 }
                    ),
                    dimensions.width
                  )}
                >
                  {'Kapt. Eddie T. Reyes Integrated School'}
                </Text>
                {/* pn4 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text 2'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text 2'].style,
                      {
                        color: theme.colors['Studily_Light_Gray_2'],
                        marginLeft: 20,
                      }
                    ),
                    dimensions.width
                  )}
                >
                  {'Pinagsama Village Phase 2, Taguig, 1630 Metro Manila'}
                </Text>
              </View>
            </Touchable>
          </AccordionGroup>
          <DivBlock />
          {/* San Miguel */}
          <AccordionGroup
            caretSize={24}
            expanded={false}
            iconSize={24}
            {...GlobalStyles.AccordionGroupStyles(theme)['Accordion'].props}
            caretColor={theme.colors['Secondary']}
            closedColor={theme.colors['Secondary']}
            label={'San Miguel'}
            openColor={theme.colors['Surface']}
            style={StyleSheet.applyWidth(
              StyleSheet.compose(
                GlobalStyles.AccordionGroupStyles(theme)['Accordion'].style,
                {
                  borderColor: theme.colors['Surface'],
                  borderStyle: 'solid',
                  fontFamily: 'Inter_500Medium',
                }
              ),
              dimensions.width
            )}
          >
            {/* sm1 */}
            <Touchable>
              {/* sm2 */}
              <View
                style={StyleSheet.applyWidth({ margin: 8 }, dimensions.width)}
              >
                {/* sm3 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text'].style,
                      { color: theme.colors['Surface'], marginLeft: 15 }
                    ),
                    dimensions.width
                  )}
                >
                  {'Eusebio Elementary School'}
                </Text>
                {/* sm4 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text 2'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text 2'].style,
                      {
                        color: theme.colors['Studily_Light_Gray_2'],
                        marginLeft: 20,
                      }
                    ),
                    dimensions.width
                  )}
                >
                  {'M. L. Quezon St Taguig, Philippines'}
                </Text>
              </View>
            </Touchable>
          </AccordionGroup>
          <DivBlock />
          {/* Santa Ana */}
          <AccordionGroup
            caretSize={24}
            expanded={false}
            iconSize={24}
            {...GlobalStyles.AccordionGroupStyles(theme)['Accordion'].props}
            caretColor={theme.colors['Secondary']}
            closedColor={theme.colors['Secondary']}
            label={'Santa Ana'}
            openColor={theme.colors['Surface']}
            style={StyleSheet.applyWidth(
              StyleSheet.compose(
                GlobalStyles.AccordionGroupStyles(theme)['Accordion'].style,
                {
                  borderColor: theme.colors['Surface'],
                  borderStyle: 'solid',
                  fontFamily: 'Inter_500Medium',
                }
              ),
              dimensions.width
            )}
          >
            {/* sa1 */}
            <Touchable>
              {/* sa2 */}
              <View
                style={StyleSheet.applyWidth({ margin: 8 }, dimensions.width)}
              >
                {/* sa3 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text'].style,
                      { color: theme.colors['Surface'], marginLeft: 15 }
                    ),
                    dimensions.width
                  )}
                >
                  {'Taguig Integrated School'}
                </Text>
                {/* sa4 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text 2'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text 2'].style,
                      {
                        color: theme.colors['Studily_Light_Gray_2'],
                        marginLeft: 20,
                      }
                    ),
                    dimensions.width
                  )}
                >
                  {'Liwayway, Taguig, 1637 Metro Manila'}
                </Text>
              </View>
            </Touchable>
          </AccordionGroup>
          <DivBlock />
          {/* South Daang Hari */}
          <AccordionGroup
            caretSize={24}
            expanded={false}
            iconSize={24}
            {...GlobalStyles.AccordionGroupStyles(theme)['Accordion'].props}
            caretColor={theme.colors['Secondary']}
            closedColor={theme.colors['Secondary']}
            label={'South Daang Hari'}
            openColor={theme.colors['Surface']}
            style={StyleSheet.applyWidth(
              StyleSheet.compose(
                GlobalStyles.AccordionGroupStyles(theme)['Accordion'].style,
                {
                  borderColor: theme.colors['Surface'],
                  borderStyle: 'solid',
                  fontFamily: 'Inter_500Medium',
                }
              ),
              dimensions.width
            )}
          >
            {/* sdh1 */}
            <Touchable>
              {/* sdh2 */}
              <View
                style={StyleSheet.applyWidth({ margin: 8 }, dimensions.width)}
              >
                {/* sdh3 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text'].style,
                      { color: theme.colors['Surface'], marginLeft: 15 }
                    ),
                    dimensions.width
                  )}
                >
                  {'Bagong Tanyag Elementary School Annex-A'}
                </Text>
                {/* sdh4 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text 2'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text 2'].style,
                      {
                        color: theme.colors['Studily_Light_Gray_2'],
                        marginLeft: 20,
                      }
                    ),
                    dimensions.width
                  )}
                >
                  {'Blk. 2 Purok 14, Sucat, Taguig, Metro Manila'}
                </Text>
              </View>
              {/* sdh5 */}
              <View
                style={StyleSheet.applyWidth({ margin: 8 }, dimensions.width)}
              >
                {/* sdh6 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text'].style,
                      { color: theme.colors['Surface'], marginLeft: 15 }
                    ),
                    dimensions.width
                  )}
                >
                  {'Bagong Tanyag Elementary School Annex-B'}
                </Text>
                {/* sdh7 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text 2'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text 2'].style,
                      {
                        color: theme.colors['Studily_Light_Gray_2'],
                        marginLeft: 20,
                      }
                    ),
                    dimensions.width
                  )}
                >
                  {'Purok 11 S.D.H, Taguig, Philippines'}
                </Text>
              </View>
            </Touchable>
          </AccordionGroup>
          <DivBlock />
          {/* South Signal Village */}
          <AccordionGroup
            caretSize={24}
            expanded={false}
            iconSize={24}
            {...GlobalStyles.AccordionGroupStyles(theme)['Accordion'].props}
            caretColor={theme.colors['Secondary']}
            closedColor={theme.colors['Secondary']}
            label={'South Signal Village'}
            openColor={theme.colors['Surface']}
            style={StyleSheet.applyWidth(
              StyleSheet.compose(
                GlobalStyles.AccordionGroupStyles(theme)['Accordion'].style,
                {
                  borderColor: theme.colors['Surface'],
                  borderStyle: 'solid',
                  fontFamily: 'Inter_500Medium',
                }
              ),
              dimensions.width
            )}
          >
            {/* ssv1 */}
            <Touchable>
              {/* ssv2 */}
              <View
                style={StyleSheet.applyWidth({ margin: 8 }, dimensions.width)}
              >
                {/* ssv3 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text'].style,
                      { color: theme.colors['Surface'], marginLeft: 15 }
                    ),
                    dimensions.width
                  )}
                >
                  {'Capt. Jose Cardones Memorial Elementary School'}
                </Text>
                {/* ssv4 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text 2'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text 2'].style,
                      {
                        color: theme.colors['Studily_Light_Gray_2'],
                        marginLeft: 20,
                      }
                    ),
                    dimensions.width
                  )}
                >
                  {'19 Friendship, Brgy, Taguig, 1633 Metro Manila'}
                </Text>
              </View>
            </Touchable>
          </AccordionGroup>
          <DivBlock />
          {/* Tanyag */}
          <AccordionGroup
            caretSize={24}
            expanded={false}
            iconSize={24}
            {...GlobalStyles.AccordionGroupStyles(theme)['Accordion'].props}
            caretColor={theme.colors['Secondary']}
            closedColor={theme.colors['Secondary']}
            label={'Tanyag'}
            openColor={theme.colors['Surface']}
            style={StyleSheet.applyWidth(
              StyleSheet.compose(
                GlobalStyles.AccordionGroupStyles(theme)['Accordion'].style,
                {
                  borderColor: theme.colors['Surface'],
                  borderStyle: 'solid',
                  fontFamily: 'Inter_500Medium',
                }
              ),
              dimensions.width
            )}
          >
            {/* tn1 */}
            <Touchable>
              {/* tn2 */}
              <View
                style={StyleSheet.applyWidth({ margin: 8 }, dimensions.width)}
              >
                {/* tn3 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text'].style,
                      { color: theme.colors['Surface'], marginLeft: 15 }
                    ),
                    dimensions.width
                  )}
                >
                  {'Bagong Tanyag Elementary School-Main'}
                </Text>
                {/* tn4 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text 2'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text 2'].style,
                      {
                        color: theme.colors['Studily_Light_Gray_2'],
                        marginLeft: 20,
                      }
                    ),
                    dimensions.width
                  )}
                >
                  {'2 South Daanghari Taguig, Philippines'}
                </Text>
              </View>
            </Touchable>
          </AccordionGroup>
          <DivBlock />
          {/* Tutukan */}
          <AccordionGroup
            caretSize={24}
            expanded={false}
            iconSize={24}
            {...GlobalStyles.AccordionGroupStyles(theme)['Accordion'].props}
            caretColor={theme.colors['Secondary']}
            closedColor={theme.colors['Secondary']}
            label={'Tutukan'}
            openColor={theme.colors['Surface']}
            style={StyleSheet.applyWidth(
              StyleSheet.compose(
                GlobalStyles.AccordionGroupStyles(theme)['Accordion'].style,
                {
                  borderColor: theme.colors['Surface'],
                  borderStyle: 'solid',
                  fontFamily: 'Inter_500Medium',
                }
              ),
              dimensions.width
            )}
          >
            {/* tt1 */}
            <Touchable>
              {/* tt2 */}
              <View
                style={StyleSheet.applyWidth({ margin: 8 }, dimensions.width)}
              >
                {/* tt3 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text'].style,
                      { color: theme.colors['Surface'], marginLeft: 15 }
                    ),
                    dimensions.width
                  )}
                >
                  {'Taguig Integrated School\n'}
                </Text>
                {/* tt4 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text 2'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text 2'].style,
                      {
                        color: theme.colors['Studily_Light_Gray_2'],
                        marginLeft: 20,
                      }
                    ),
                    dimensions.width
                  )}
                >
                  {'Liwayway, Taguig, 1637 Metro Manila'}
                </Text>
              </View>
            </Touchable>
          </AccordionGroup>
          <DivBlock />
          {/* Upper Bicutan */}
          <AccordionGroup
            caretSize={24}
            expanded={false}
            iconSize={24}
            {...GlobalStyles.AccordionGroupStyles(theme)['Accordion'].props}
            caretColor={theme.colors['Secondary']}
            closedColor={theme.colors['Secondary']}
            label={'Upper Bicutan'}
            openColor={theme.colors['Surface']}
            style={StyleSheet.applyWidth(
              StyleSheet.compose(
                GlobalStyles.AccordionGroupStyles(theme)['Accordion'].style,
                {
                  borderColor: theme.colors['Surface'],
                  borderStyle: 'solid',
                  fontFamily: 'Inter_500Medium',
                }
              ),
              dimensions.width
            )}
          >
            {/* ub1 */}
            <Touchable>
              {/* ub2 */}
              <View
                style={StyleSheet.applyWidth({ margin: 8 }, dimensions.width)}
              >
                {/* ub3 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text'].style,
                      { color: theme.colors['Surface'], marginLeft: 15 }
                    ),
                    dimensions.width
                  )}
                >
                  {'Silangan Elementary School'}
                </Text>
                {/* ub4 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text 2'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text 2'].style,
                      {
                        color: theme.colors['Studily_Light_Gray_2'],
                        marginLeft: 20,
                      }
                    ),
                    dimensions.width
                  )}
                >
                  {'Maharlika Rd, Taguig, Metro Manila'}
                </Text>
              </View>
            </Touchable>
          </AccordionGroup>
          <DivBlock />
          {/* Ususan */}
          <AccordionGroup
            caretSize={24}
            expanded={false}
            iconSize={24}
            {...GlobalStyles.AccordionGroupStyles(theme)['Accordion'].props}
            caretColor={theme.colors['Secondary']}
            closedColor={theme.colors['Secondary']}
            label={'Ususan'}
            openColor={theme.colors['Studily_Light_Gray_2']}
            style={StyleSheet.applyWidth(
              StyleSheet.compose(
                GlobalStyles.AccordionGroupStyles(theme)['Accordion'].style,
                {
                  borderColor: theme.colors['Surface'],
                  borderStyle: 'solid',
                  fontFamily: 'Inter_400Regular',
                }
              ),
              dimensions.width
            )}
          >
            {/* uss1 */}
            <Touchable>
              {/* uss2 */}
              <View
                style={StyleSheet.applyWidth({ margin: 8 }, dimensions.width)}
              >
                {/* uss3 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text'].style,
                      { color: theme.colors['Surface'], marginLeft: 15 }
                    ),
                    dimensions.width
                  )}
                >
                  {'Ususan Elementary School'}
                </Text>
                {/* uss4 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text 2'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text 2'].style,
                      {
                        color: theme.colors['Studily_Light_Gray_2'],
                        marginLeft: 20,
                      }
                    ),
                    dimensions.width
                  )}
                >
                  {'76, Gen. Luna, Ususan Taguig, Philippines'}
                </Text>
              </View>
              {/* uss5 */}
              <View
                style={StyleSheet.applyWidth({ margin: 8 }, dimensions.width)}
              >
                {/* uss6 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text'].style,
                      { color: theme.colors['Surface'], marginLeft: 15 }
                    ),
                    dimensions.width
                  )}
                >
                  {'Cayetano Science Highschool'}
                </Text>
                {/* uss7 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text 2'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text 2'].style,
                      {
                        color: theme.colors['Studily_Light_Gray_2'],
                        marginLeft: 20,
                      }
                    ),
                    dimensions.width
                  )}
                >
                  {'25th Street, Taguig, Philippines'}
                </Text>
              </View>
            </Touchable>
          </AccordionGroup>
          <DivBlock />
          {/* Wawa */}
          <AccordionGroup
            caretSize={24}
            expanded={false}
            iconSize={24}
            {...GlobalStyles.AccordionGroupStyles(theme)['Accordion'].props}
            caretColor={theme.colors['Secondary']}
            closedColor={theme.colors['Secondary']}
            label={'Wawa'}
            openColor={theme.colors['Surface']}
            style={StyleSheet.applyWidth(
              StyleSheet.compose(
                GlobalStyles.AccordionGroupStyles(theme)['Accordion'].style,
                {
                  borderColor: theme.colors['Surface'],
                  borderStyle: 'solid',
                  fontFamily: 'Inter_500Medium',
                }
              ),
              dimensions.width
            )}
          >
            {/* ww1 */}
            <Touchable>
              {/* ww2 */}
              <View
                style={StyleSheet.applyWidth({ margin: 8 }, dimensions.width)}
              >
                {/* ww3 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text'].style,
                      { color: theme.colors['Surface'], marginLeft: 15 }
                    ),
                    dimensions.width
                  )}
                >
                  {'Eusebio Elementary School'}
                </Text>
                {/* ww4 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text 2'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text 2'].style,
                      {
                        color: theme.colors['Studily_Light_Gray_2'],
                        marginLeft: 20,
                      }
                    ),
                    dimensions.width
                  )}
                >
                  {'M. L. Quezon St Taguig, Philippines'}
                </Text>
              </View>
            </Touchable>
          </AccordionGroup>
          <DivBlock />
          {/* Western Bicutan */}
          <AccordionGroup
            caretSize={24}
            expanded={false}
            iconSize={24}
            {...GlobalStyles.AccordionGroupStyles(theme)['Accordion'].props}
            caretColor={theme.colors['Secondary']}
            closedColor={theme.colors['Secondary']}
            label={'Western Bicutan'}
            openColor={theme.colors['Surface']}
            style={StyleSheet.applyWidth(
              StyleSheet.compose(
                GlobalStyles.AccordionGroupStyles(theme)['Accordion'].style,
                {
                  borderColor: theme.colors['Surface'],
                  borderStyle: 'solid',
                  fontFamily: 'Inter_500Medium',
                }
              ),
              dimensions.width
            )}
          >
            {/* wb1 */}
            <Touchable>
              {/* wb2 */}
              <View
                style={StyleSheet.applyWidth({ margin: 8 }, dimensions.width)}
              >
                {/* wb3 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text'].style,
                      { color: theme.colors['Surface'], marginLeft: 15 }
                    ),
                    dimensions.width
                  )}
                >
                  {'Tenement Elementary School'}
                </Text>
                {/* wb4 */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text 2'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text 2'].style,
                      {
                        color: theme.colors['Studily_Light_Gray_2'],
                        marginLeft: 20,
                      }
                    ),
                    dimensions.width
                  )}
                >
                  {'Veterans Rd, Taguig, 1630 Metro Manila'}
                </Text>
              </View>
            </Touchable>
          </AccordionGroup>
        </VStack>
      </SimpleStyleScrollView>
      {/* ibakbyu */}
      <View
        style={StyleSheet.applyWidth(
          { bottom: 0, marginTop: 10, position: 'absolute', width: '100%' },
          dimensions.width
        )}
      >
        <EvacNBBlock />
      </View>
    </ScreenContainer>
  );
};

export default withTheme(EvacuationCentersScreen);
