import React from 'react';
import HomeNBBlock from '../components/HomeNBBlock';
import Breakpoints from '../utils/Breakpoints';
import * as StyleSheet from '../utils/StyleSheet';
import useWindowDimensions from '../utils/useWindowDimensions';
import { MapMarker, MapView } from '@draftbit/maps';
import { Icon, ScreenContainer, TextInput, withTheme } from '@draftbit/ui';
import { View } from 'react-native';

const HomeScreen = props => {
  const { theme } = props;
  const dimensions = useWindowDimensions();
  const [switchValue, setSwitchValue] = React.useState(false);
  const [textInputValue, setTextInputValue] = React.useState('');
  const [textInputValue2, setTextInputValue2] = React.useState('');

  return (
    <ScreenContainer
      scrollable={false}
      hasBottomSafeArea={false}
      hasSafeArea={true}
      hasTopSafeArea={false}
      style={StyleSheet.applyWidth(
        { backgroundColor: theme.colors['Primary'], justifyContent: 'center' },
        dimensions.width
      )}
    >
      {/* hea */}
      <View
        style={StyleSheet.applyWidth(
          {
            alignContent: 'center',
            backgroundColor: theme.colors['Primary'],
            flexDirection: 'column',
            flexWrap: 'nowrap',
            height: 50,
            justifyContent: 'space-between',
            paddingLeft: 16,
            paddingRight: 16,
          },
          dimensions.width
        )}
      >
        {/* sae */}
        <View
          style={StyleSheet.applyWidth(
            {
              alignItems: 'center',
              flex: 1,
              flexDirection: 'row',
              height: 38,
              justifyContent: 'center',
            },
            dimensions.width
          )}
        >
          {/* addr */}
          <View
            style={StyleSheet.applyWidth(
              {
                alignItems: 'center',
                borderBottomWidth: 1,
                borderColor: theme.colors['Surface'],
                borderLeftWidth: 1,
                borderRadius: 10,
                borderRightWidth: 1,
                borderTopWidth: 1,
                flex: 1,
                flexDirection: 'row',
                paddingLeft: 12,
              },
              dimensions.width
            )}
          >
            {/* ic */}
            <Icon
              color={theme.colors['Surface']}
              name={'Ionicons/search-outline'}
              size={18}
            />
            {/* byu */}
            <View
              style={StyleSheet.applyWidth(
                { flex: 1, paddingLeft: 8, paddingRight: 8 },
                dimensions.width
              )}
            >
              {/* kmo */}
              <TextInput
                autoCapitalize={'none'}
                autoCorrect={true}
                changeTextDelay={500}
                webShowOutline={true}
                placeholder={'Search for a location...'}
                style={StyleSheet.applyWidth(
                  {
                    borderRadius: 8,
                    color: theme.colors['Surface'],
                    fontFamily: 'Inter_500Medium',
                    fontSize: 12,
                    height: 28,
                    paddingBottom: 8,
                    paddingLeft: 8,
                    paddingRight: 8,
                    paddingTop: 8,
                  },
                  dimensions.width
                )}
              />
            </View>
          </View>
        </View>
      </View>
      {/* lasd */}
      <View
        style={StyleSheet.applyWidth(
          { flex: 1, marginBottom: 60, marginLeft: 10, marginRight: 10 },
          dimensions.width
        )}
      >
        {/* pagp */}
        <MapView
          apiKey={'AIzaSyDaaDKi5Q2QNaprFUU50KABCb5Q_PpWXi0'}
          autoClusterMarkers={false}
          autoClusterMarkersDistanceMeters={10000}
          customMapStyle={'Beautiful West Coast Villa'}
          latitude={37.40241}
          loadingEnabled={true}
          longitude={-122.12125}
          moveOnMarkerPress={true}
          rotateEnabled={true}
          scrollEnabled={true}
          showsPointsOfInterest={true}
          zoomEnabled={true}
          followsUserLocation={true}
          loadingBackgroundColor={theme.colors['Primary']}
          loadingIndicatorColor={theme.colors['Secondary']}
          mapType={'standard'}
          provider={'google'}
          showsCompass={true}
          showsUserLocation={true}
          style={StyleSheet.applyWidth({ flex: 1 }, dimensions.width)}
          zoom={15}
        >
          <MapMarker
            androidUseDefaultIconImplementation={false}
            flat={false}
            pinImageSize={50}
            tracksViewChanges={true}
          />
        </MapView>
      </View>
      {/* byu2 */}
      <View>
        <HomeNBBlock />
      </View>
    </ScreenContainer>
  );
};

export default withTheme(HomeScreen);
