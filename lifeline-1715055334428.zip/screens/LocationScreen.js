import React from 'react';
import * as GlobalVariables from '../config/GlobalVariableContext';
import Images from '../config/Images';
import Breakpoints from '../utils/Breakpoints';
import * as StyleSheet from '../utils/StyleSheet';
import getLocationUtil from '../utils/getLocation';
import useWindowDimensions from '../utils/useWindowDimensions';
import { Button, ScreenContainer, Touchable, withTheme } from '@draftbit/ui';
import { Image, Text, View } from 'react-native';

const LocationScreen = props => {
  const { theme, navigation } = props;
  const dimensions = useWindowDimensions();
  const Constants = GlobalVariables.useValues();
  const Variables = Constants;
  const setGlobalVariableValue = GlobalVariables.useSetValue();

  return (
    <ScreenContainer
      scrollable={false}
      hasSafeArea={true}
      style={StyleSheet.applyWidth(
        { justifyContent: 'flex-end' },
        dimensions.width
      )}
    >
      {/* pog */}
      <View
        style={StyleSheet.applyWidth(
          {
            alignItems: 'center',
            flexGrow: 1,
            flexShrink: 0,
            maxHeight: '34%',
            minHeight: '33%',
          },
          dimensions.width
        )}
      >
        {/* poh */}
        <Image
          resizeMode={'contain'}
          source={Images.ImgLoc}
          style={StyleSheet.applyWidth(
            { height: 150, marginBottom: 12, width: 150 },
            dimensions.width
          )}
        />
        {/* poj */}
        <Text
          accessible={true}
          style={StyleSheet.applyWidth(
            {
              color: theme.colors['Surface'],
              fontFamily: 'Inter_700Bold',
              fontSize: 24,
              lineHeight: 32,
            },
            dimensions.width
          )}
        >
          {'Enable Location'}
        </Text>
        {/* poq */}
        <Text
          accessible={true}
          ellipsizeMode={'middle'}
          style={StyleSheet.applyWidth(
            {
              alignSelf: 'center',
              color: theme.colors['Studily_Light_Gray_2'],
              fontFamily: 'Inter_400Regular',
              fontSize: 12,
              marginLeft: 18,
              marginRight: 18,
              textAlign: 'center',
            },
            dimensions.width
          )}
        >
          {
            'Allow Lifeline to access your current location and to navigate to nearby evacuation centers.'
          }
        </Text>
      </View>
      {/* pom */}
      <View
        style={StyleSheet.applyWidth(
          {
            flexGrow: 1,
            flexShrink: 0,
            justifyContent: 'flex-end',
            maxHeight: '33%',
            minHeight: '33%',
            paddingBottom: 30,
            paddingLeft: 12,
            paddingRight: 12,
          },
          dimensions.width
        )}
      >
        {/* pon */}
        <Touchable
          onPress={() => {
            try {
              setGlobalVariableValue({
                key: 'onLoc',
                value: 0,
              });
              navigation.navigate('NotificationScreen');
            } catch (err) {
              console.error(err);
            }
          }}
        >
          {/* qwerty */}
          <Text
            accessible={true}
            style={StyleSheet.applyWidth(
              {
                color: theme.colors.light,
                fontFamily: 'Inter_600SemiBold',
                lineHeight: 24,
                textAlign: 'center',
                textTransform: 'uppercase',
              },
              dimensions.width
            )}
          >
            {'Skip'}
          </Text>
        </Touchable>
        {/* pob */}
        <Button
          onPress={() => {
            const handler = async () => {
              try {
                const currentLoc = await getLocationUtil();
                setGlobalVariableValue({
                  key: 'onLoc',
                  value: 1,
                });
                navigation.navigate('NotificationScreen', {
                  currLoc: currentLoc,
                });
              } catch (err) {
                console.error(err);
              }
            };
            handler();
          }}
          style={StyleSheet.applyWidth(
            {
              alignItems: 'center',
              backgroundColor: theme.colors['Secondary'],
              borderRadius: 60,
              flexDirection: 'row',
              fontFamily: 'Inter_700Bold',
              justifyContent: 'center',
              marginTop: 16,
            },
            dimensions.width
          )}
          title={'ENABLE LOCATION'}
        >
          {'Sign Up'}
        </Button>
      </View>
    </ScreenContainer>
  );
};

export default withTheme(LocationScreen);
