import React from 'react';
import * as GlobalVariables from '../config/GlobalVariableContext';
import Images from '../config/Images';
import Breakpoints from '../utils/Breakpoints';
import * as StyleSheet from '../utils/StyleSheet';
import setNotificationBadgeCountUtil from '../utils/setNotificationBadgeCount';
import useWindowDimensions from '../utils/useWindowDimensions';
import { Button, ScreenContainer, withTheme } from '@draftbit/ui';
import { Image, Text, View } from 'react-native';

const NotificationScreen = props => {
  const { theme, navigation } = props;
  const dimensions = useWindowDimensions();
  const Constants = GlobalVariables.useValues();
  const Variables = Constants;
  const setGlobalVariableValue = GlobalVariables.useSetValue();

  return (
    <ScreenContainer
      scrollable={false}
      hasSafeArea={true}
      style={StyleSheet.applyWidth(
        { justifyContent: 'space-around', paddingLeft: 16, paddingRight: 16 },
        dimensions.width
      )}
    >
      {/* byi */}
      <View
        style={StyleSheet.applyWidth(
          { flex: 1, justifyContent: 'space-between', marginBottom: 20 },
          dimensions.width
        )}
      >
        {/* kio */}
        <View
          style={StyleSheet.applyWidth(
            { alignItems: 'center', flex: 1, justifyContent: 'center' },
            dimensions.width
          )}
        >
          {/* cvds */}
          <Image
            resizeMode={'cover'}
            source={Images.ImgNotif}
            style={StyleSheet.applyWidth(
              { height: 150, width: 150 },
              dimensions.width
            )}
          />
          {/* ret */}
          <Text
            accessible={true}
            style={StyleSheet.applyWidth(
              {
                color: theme.colors['Surface'],
                fontFamily: 'Inter_700Bold',
                fontSize: 24,
                lineHeight: 32,
                textAlign: 'center',
              },
              dimensions.width
            )}
          >
            {'Enable Notifications'}
          </Text>
          {/* tr */}
          <Text
            accessible={true}
            style={StyleSheet.applyWidth(
              {
                color: theme.colors['Studily_Light_Gray_2'],
                fontFamily: 'Inter_400Regular',
                fontSize: 12,
                lineHeight: 24,
                textAlign: 'center',
              },
              dimensions.width
            )}
          >
            {'Stay up to date with the latest updates and alerts. '}
          </Text>
        </View>
        {/* bvc */}
        <View
          style={StyleSheet.applyWidth(
            { justifyContent: 'space-evenly' },
            dimensions.width
          )}
        >
          {/* lkj */}
          <Button
            onPress={() => {
              try {
                setGlobalVariableValue({
                  key: 'onNotif',
                  value: 0,
                });
                if (navigation.canGoBack()) {
                  navigation.popToTop();
                }
                navigation.replace('HomeScreen');
              } catch (err) {
                console.error(err);
              }
            }}
            style={StyleSheet.applyWidth(
              {
                alignItems: 'center',
                backgroundColor: theme.colors.background,
                borderRadius: 64,
                color: theme.colors.light,
                flexDirection: 'row',
                fontFamily: 'Inter_700Bold',
                justifyContent: 'center',
                marginTop: 16,
                textAlign: 'center',
              },
              dimensions.width
            )}
            title={'SKIP'}
          >
            {'Sign Up'}
          </Button>
          {/* ngd */}
          <Button
            onPress={() => {
              const handler = async () => {
                try {
                  const onNotifs = await setNotificationBadgeCountUtil({
                    badgeCount: 1,
                    permissionErrorMessage:
                      'Sorry, we need notifications permissions to make this work.',
                    deviceErrorMessage:
                      'Must use physical device for Push Notifications.',
                    showAlertOnPermissionError: true,
                    showAlertOnDeviceError: true,
                  });
                  setGlobalVariableValue({
                    key: 'onNotif',
                    value: 1,
                  });
                  if (navigation.canGoBack()) {
                    navigation.popToTop();
                  }
                  navigation.replace('HomeScreen');
                } catch (err) {
                  console.error(err);
                }
              };
              handler();
            }}
            style={StyleSheet.applyWidth(
              {
                alignItems: 'center',
                backgroundColor: theme.colors['Secondary'],
                borderRadius: 64,
                flexDirection: 'row',
                fontFamily: 'Inter_700Bold',
                justifyContent: 'center',
                marginTop: 16,
                textAlign: 'center',
              },
              dimensions.width
            )}
            title={'ENABLE NOTIFICATIONS'}
          >
            {'Sign Up'}
          </Button>
        </View>
      </View>
    </ScreenContainer>
  );
};

export default withTheme(NotificationScreen);
