import React from 'react';
import Breakpoints from '../utils/Breakpoints';
import * as StyleSheet from '../utils/StyleSheet';
import useWindowDimensions from '../utils/useWindowDimensions';
import {
  Circle,
  Icon,
  Link,
  ScreenContainer,
  SimpleStyleKeyboardAwareScrollView,
  Spacer,
  TextInput,
  Touchable,
  withTheme,
} from '@draftbit/ui';
import { Text, View } from 'react-native';

const OTPScreen = props => {
  const { theme, navigation } = props;
  const dimensions = useWindowDimensions();
  const [input1, setInput1] = React.useState(0);
  const [input2, setInput2] = React.useState(0);
  const [input3, setInput3] = React.useState(0);
  const [input4, setInput4] = React.useState(0);

  return (
    <ScreenContainer
      hasSafeArea={false}
      scrollable={false}
      style={StyleSheet.applyWidth(
        { backgroundColor: theme.colors['Background'] },
        dimensions.width
      )}
    >
      {/* KAWS2 */}
      <SimpleStyleKeyboardAwareScrollView
        enableAutomaticScroll={false}
        enableOnAndroid={false}
        enableResetScrollToCoords={false}
        keyboardShouldPersistTaps={'never'}
        showsVerticalScrollIndicator={true}
        viewIsInsideTabBar={false}
        style={StyleSheet.applyWidth(
          {
            flex: 1,
            justifyContent: 'center',
            paddingBottom: 36,
            paddingLeft: 36,
            paddingRight: 36,
            paddingTop: 36,
          },
          dimensions.width
        )}
      >
        {/* VIEW1 */}
        <View>
          {/* H123 */}
          <View
            style={StyleSheet.applyWidth(
              { alignItems: 'center' },
              dimensions.width
            )}
          >
            {/* T123 */}
            <Text
              accessible={true}
              style={StyleSheet.applyWidth(
                {
                  color: theme.colors['Surface'],
                  fontFamily: 'Inter_700Bold',
                  fontSize: 32,
                },
                dimensions.width
              )}
            >
              {'Verification'}
            </Text>
            {/* t1234 */}
            <Text
              accessible={true}
              style={StyleSheet.applyWidth(
                {
                  color: theme.colors.studilyLightGray2,
                  fontFamily: 'Inter_500Medium',
                  fontSize: 15,
                  marginTop: 8,
                  textAlign: 'center',
                },
                dimensions.width
              )}
            >
              {'We sent you a text message\nwith a 4-digit code'}
            </Text>
          </View>
          {/* S123 */}
          <Spacer left={8} right={8} bottom={16} top={16} />
          {/* F123 */}
          <View
            style={StyleSheet.applyWidth(
              { flexDirection: 'row' },
              dimensions.width
            )}
          >
            {/* V123Q */}
            <View
              style={StyleSheet.applyWidth(
                {
                  backgroundColor: theme.colors.studilyWhite3,
                  borderBottomWidth: 1,
                  borderColor: theme.colors.studilyGray4,
                  borderLeftWidth: 1,
                  borderRadius: 12,
                  borderRightWidth: 1,
                  borderTopWidth: 1,
                  flex: 1,
                  overflow: 'hidden',
                },
                dimensions.width
              )}
            >
              {/* V123W */}
              <View
                style={StyleSheet.applyWidth(
                  {
                    paddingBottom: 16,
                    paddingLeft: 16,
                    paddingRight: 16,
                    paddingTop: 16,
                  },
                  dimensions.width
                )}
              >
                {/* TI123 */}
                <TextInput
                  autoCapitalize={'none'}
                  autoCorrect={true}
                  changeTextDelay={500}
                  webShowOutline={true}
                  defaultValue={input1}
                  keyboardType={'numeric'}
                  maxLength={1}
                  placeholder={''}
                  style={StyleSheet.applyWidth(
                    {
                      color: theme.colors.studilyMediumUI,
                      fontFamily: 'Inter_500Medium',
                      fontSize: 24,
                      textAlign: 'center',
                    },
                    dimensions.width
                  )}
                />
              </View>
            </View>
            {/* S123Q */}
            <Spacer bottom={8} left={8} right={8} top={8} />
            {/* V123E */}
            <View
              style={StyleSheet.applyWidth(
                {
                  backgroundColor: theme.colors.studilyWhite3,
                  borderBottomWidth: 1,
                  borderColor: theme.colors.studilyGray4,
                  borderLeftWidth: 1,
                  borderRadius: 12,
                  borderRightWidth: 1,
                  borderTopWidth: 1,
                  flex: 1,
                  overflow: 'hidden',
                },
                dimensions.width
              )}
            >
              {/* R */}
              <View
                style={StyleSheet.applyWidth(
                  {
                    paddingBottom: 16,
                    paddingLeft: 16,
                    paddingRight: 16,
                    paddingTop: 16,
                  },
                  dimensions.width
                )}
              >
                {/* TI123T */}
                <TextInput
                  autoCapitalize={'none'}
                  autoCorrect={true}
                  changeTextDelay={500}
                  webShowOutline={true}
                  defaultValue={input2}
                  keyboardType={'numeric'}
                  maxLength={1}
                  placeholder={''}
                  style={StyleSheet.applyWidth(
                    {
                      color: theme.colors.studilyMediumUI,
                      fontFamily: 'Inter_500Medium',
                      fontSize: 24,
                      textAlign: 'center',
                    },
                    dimensions.width
                  )}
                />
              </View>
            </View>
            {/* S1234 */}
            <Spacer bottom={8} left={8} right={8} top={8} />
            {/* VIEW2 */}
            <View
              style={StyleSheet.applyWidth(
                {
                  backgroundColor: theme.colors.studilyWhite3,
                  borderBottomWidth: 1,
                  borderColor: theme.colors.studilyGray4,
                  borderLeftWidth: 1,
                  borderRadius: 12,
                  borderRightWidth: 1,
                  borderTopWidth: 1,
                  flex: 1,
                  overflow: 'hidden',
                },
                dimensions.width
              )}
            >
              {/* IEW3 */}
              <View
                style={StyleSheet.applyWidth(
                  {
                    paddingBottom: 16,
                    paddingLeft: 16,
                    paddingRight: 16,
                    paddingTop: 16,
                  },
                  dimensions.width
                )}
              >
                {/* TI098 */}
                <TextInput
                  autoCapitalize={'none'}
                  autoCorrect={true}
                  changeTextDelay={500}
                  webShowOutline={true}
                  defaultValue={input3}
                  keyboardType={'numeric'}
                  maxLength={1}
                  placeholder={''}
                  style={StyleSheet.applyWidth(
                    {
                      color: theme.colors.studilyMediumUI,
                      fontFamily: 'Inter_500Medium',
                      fontSize: 24,
                      textAlign: 'center',
                    },
                    dimensions.width
                  )}
                />
              </View>
            </View>
            {/* SPO */}
            <Spacer bottom={8} left={8} right={8} top={8} />
            {/* VBN */}
            <View
              style={StyleSheet.applyWidth(
                {
                  backgroundColor: theme.colors.studilyWhite3,
                  borderBottomWidth: 1,
                  borderColor: theme.colors.studilyGray4,
                  borderLeftWidth: 1,
                  borderRadius: 12,
                  borderRightWidth: 1,
                  borderTopWidth: 1,
                  flex: 1,
                  overflow: 'hidden',
                },
                dimensions.width
              )}
            >
              {/* VLN */}
              <View
                style={StyleSheet.applyWidth(
                  {
                    paddingBottom: 16,
                    paddingLeft: 16,
                    paddingRight: 16,
                    paddingTop: 16,
                  },
                  dimensions.width
                )}
              >
                {/* TI87 */}
                <TextInput
                  autoCapitalize={'none'}
                  autoCorrect={true}
                  changeTextDelay={500}
                  webShowOutline={true}
                  defaultValue={input4}
                  keyboardType={'numeric'}
                  maxLength={1}
                  placeholder={''}
                  style={StyleSheet.applyWidth(
                    {
                      color: theme.colors.studilyMediumUI,
                      fontFamily: 'Inter_500Medium',
                      fontSize: 24,
                      textAlign: 'center',
                    },
                    dimensions.width
                  )}
                />
              </View>
            </View>
          </View>
          {/* SPA */}
          <Spacer left={8} right={8} bottom={24} top={24} />
          {/* B123 */}
          <View>
            {/* FLKLK */}
            <View
              style={StyleSheet.applyWidth({ zIndex: 10 }, dimensions.width)}
            >
              {/* POQWE */}
              <Touchable
                onPress={() => {
                  try {
                    navigation.navigate('LocationScreen');
                  } catch (err) {
                    console.error(err);
                  }
                }}
              >
                {/* LOK */}
                <View
                  style={StyleSheet.applyWidth(
                    {
                      backgroundColor: theme.colors['Secondary'],
                      borderRadius: 12,
                      flexDirection: 'row',
                      paddingBottom: 12,
                      paddingLeft: 18,
                      paddingRight: 18,
                      paddingTop: 12,
                      zIndex: 10,
                    },
                    dimensions.width
                  )}
                >
                  {/* ERT */}
                  <View
                    style={StyleSheet.applyWidth(
                      {
                        alignItems: 'center',
                        flexGrow: 1,
                        flexShrink: 0,
                        justifyContent: 'center',
                      },
                      dimensions.width
                    )}
                  >
                    {/* KMHJ */}
                    <Text
                      accessible={true}
                      style={StyleSheet.applyWidth(
                        {
                          color: theme.colors.studilyWhite3,
                          fontFamily: 'Nunito_700Bold',
                          fontSize: 15,
                          lineHeight: 21,
                          marginLeft: 42,
                          textTransform: 'uppercase',
                        },
                        dimensions.width
                      )}
                    >
                      {'Continue'}
                    </Text>
                  </View>
                  {/* POL */}
                  <View>
                    {/* LOP */}
                    <Circle bgColor={theme.colors.studily25Percent} size={42}>
                      {/* POK */}
                      <View
                        style={StyleSheet.applyWidth(
                          {
                            flexGrow: 0,
                            flexShrink: 0,
                            paddingBottom: 12,
                            paddingLeft: 12,
                            paddingRight: 12,
                            paddingTop: 12,
                          },
                          dimensions.width
                        )}
                      >
                        {/* POI */}
                        <Icon
                          color={theme.colors.studilyWhite3}
                          name={'AntDesign/arrowright'}
                          size={18}
                        />
                      </View>
                    </Circle>
                  </View>
                </View>
              </Touchable>
            </View>
          </View>
          {/* slop */}
          <Spacer left={8} right={8} bottom={16} top={16} />
          {/* jud */}
          <View
            style={StyleSheet.applyWidth(
              { alignItems: 'center' },
              dimensions.width
            )}
          >
            {/* qwe */}
            <Text
              accessible={true}
              style={StyleSheet.applyWidth(
                {
                  color: theme.colors.studilyLightGray2,
                  fontFamily: 'Inter_400Regular',
                },
                dimensions.width
              )}
            >
              {"Didn't receive a code?"}
            </Text>
            {/* nmk */}
            <Link
              accessible={true}
              style={StyleSheet.applyWidth(
                {
                  color: theme.colors['Secondary'],
                  fontFamily: 'Inter_700Bold',
                  fontSize: 16,
                  marginTop: 8,
                },
                dimensions.width
              )}
              title={'RESEND'}
            />
          </View>
        </View>
      </SimpleStyleKeyboardAwareScrollView>
    </ScreenContainer>
  );
};

export default withTheme(OTPScreen);
