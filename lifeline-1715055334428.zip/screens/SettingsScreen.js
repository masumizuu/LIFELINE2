import React from 'react';
import * as GlobalStyles from '../GlobalStyles.js';
import SettNBBlock from '../components/SettNBBlock';
import * as GlobalVariables from '../config/GlobalVariableContext';
import is11 from '../global-functions/is11';
import isTrue from '../global-functions/isTrue';
import Breakpoints from '../utils/Breakpoints';
import * as StyleSheet from '../utils/StyleSheet';
import useWindowDimensions from '../utils/useWindowDimensions';
import {
  AccordionGroup,
  Button,
  Icon,
  IconButton,
  KeyboardAvoidingView,
  ScreenContainer,
  SimpleStyleScrollView,
  Spacer,
  Switch,
  TextInput,
  Touchable,
  withTheme,
} from '@draftbit/ui';
import { Modal, Text, View } from 'react-native';

const SettingsScreen = props => {
  const { theme, navigation } = props;
  const dimensions = useWindowDimensions();
  const Constants = GlobalVariables.useValues();
  const Variables = Constants;
  const setGlobalVariableValue = GlobalVariables.useSetValue();
  const [NewNumModal, setNewNumModal] = React.useState(0);
  const [NewOTPModal, setNewOTPModal] = React.useState(0);
  const [input1, setInput1] = React.useState(0);
  const [input2, setInput2] = React.useState(0);
  const [input3, setInput3] = React.useState(0);
  const [input4, setInput4] = React.useState(0);
  const [numberInputValue, setNumberInputValue] = React.useState('');
  const [switchValue, setSwitchValue] = React.useState(false);
  const [switchValue2, setSwitchValue2] = React.useState(false);
  const [switchValue3, setSwitchValue3] = React.useState(false);
  const [textInputValue, setTextInputValue] = React.useState('');

  return (
    <ScreenContainer hasSafeArea={true} scrollable={true}>
      {/* ssv1 */}
      <SimpleStyleScrollView
        bounces={true}
        horizontal={false}
        keyboardShouldPersistTaps={'never'}
        nestedScrollEnabled={false}
        showsHorizontalScrollIndicator={true}
        showsVerticalScrollIndicator={true}
      >
        {/* sv2 */}
        <View
          style={StyleSheet.applyWidth(
            { alignItems: 'center', paddingTop: 150 },
            dimensions.width
          )}
        >
          {/* st3 */}
          <Text
            accessible={true}
            style={StyleSheet.applyWidth(
              {
                color: theme.colors['Surface'],
                fontFamily: 'Inter_700Bold',
                fontSize: 20,
                lineHeight: 24,
                marginBottom: 6,
                textTransform: 'uppercase',
              },
              dimensions.width
            )}
          >
            {'Settings'}
          </Text>
        </View>
        {/* sv4 */}
        <View
          style={StyleSheet.applyWidth(
            { marginLeft: 15, marginRight: 15, paddingTop: 50 },
            dimensions.width
          )}
        >
          {/* stac6 */}
          <AccordionGroup
            caretSize={24}
            expanded={false}
            iconSize={24}
            {...GlobalStyles.AccordionGroupStyles(theme)['Accordion'].props}
            caretColor={theme.colors['Surface']}
            closedColor={theme.colors['Surface']}
            icon={'Feather/info'}
            label={'About'}
            openColor={theme.colors['Surface']}
            style={StyleSheet.applyWidth(
              StyleSheet.compose(
                GlobalStyles.AccordionGroupStyles(theme)['Accordion'].style,
                {
                  color: theme.colors['Surface'],
                  fontFamily: 'Inter_400Regular',
                  fontSize: 14,
                }
              ),
              dimensions.width
            )}
          >
            {/* sv5 */}
            <View
              style={StyleSheet.applyWidth(
                { marginLeft: 20, marginRight: 20, marginTop: 10 },
                dimensions.width
              )}
            >
              {/* st7 */}
              <Text
                accessible={true}
                {...GlobalStyles.TextStyles(theme)['Text 2'].props}
                style={StyleSheet.applyWidth(
                  StyleSheet.compose(
                    GlobalStyles.TextStyles(theme)['Text 2'].style,
                    {
                      color: theme.colors['Surface'],
                      fontFamily: 'Inter_400Regular',
                      fontSize: 12,
                    }
                  ),
                  dimensions.width
                )}
              >
                {
                  "Lifeline is an emergency application specifically designed to provide useful emergency procedures for any emergency situations. It's simple yet elegant design is tailored to accommodate urgent emergencies. Lifeline helps its users to be prepared on what's to come."
                }
              </Text>
            </View>
          </AccordionGroup>
          {/* spr1 */}
          <Spacer bottom={8} left={8} right={8} top={8} />
          {/* sacc8 */}
          <AccordionGroup
            caretSize={24}
            expanded={false}
            iconSize={24}
            {...GlobalStyles.AccordionGroupStyles(theme)['Accordion'].props}
            caretColor={theme.colors['Surface']}
            closedColor={theme.colors['Surface']}
            icon={'FontAwesome/user-circle'}
            label={'Account Settings'}
            openColor={theme.colors['Surface']}
            style={StyleSheet.applyWidth(
              StyleSheet.compose(
                GlobalStyles.AccordionGroupStyles(theme)['Accordion'].style,
                {
                  color: theme.colors['Surface'],
                  fontFamily: 'Inter_400Regular',
                  fontSize: 14,
                }
              ),
              dimensions.width
            )}
          >
            {/* stv101 */}
            <View
              style={StyleSheet.applyWidth(
                { marginLeft: 20, marginRight: 20 },
                dimensions.width
              )}
            >
              {/* stphonenum */}
              <Text
                accessible={true}
                {...GlobalStyles.TextStyles(theme)['Text'].props}
                style={StyleSheet.applyWidth(
                  StyleSheet.compose(
                    GlobalStyles.TextStyles(theme)['Text'].style,
                    {
                      color: theme.colors['Secondary'],
                      fontFamily: 'Inter_500Medium',
                      fontSize: 16,
                    }
                  ),
                  dimensions.width
                )}
              >
                {Constants['phoneNum']}
              </Text>
            </View>
            {/* svv9 */}
            <View
              style={StyleSheet.applyWidth(
                {
                  flexDirection: 'row',
                  marginLeft: 20,
                  marginRight: 20,
                  marginTop: 10,
                },
                dimensions.width
              )}
            >
              {/* stch11 */}
              <Touchable
                onPress={() => {
                  try {
                    setNewNumModal(1);
                  } catch (err) {
                    console.error(err);
                  }
                }}
              >
                {/* stvv22 */}
                <View
                  style={StyleSheet.applyWidth(
                    { flexDirection: 'row' },
                    dimensions.width
                  )}
                >
                  {/* sttt33 */}
                  <Text
                    accessible={true}
                    {...GlobalStyles.TextStyles(theme)['Text 2'].props}
                    style={StyleSheet.applyWidth(
                      StyleSheet.compose(
                        GlobalStyles.TextStyles(theme)['Text 2'].style,
                        {
                          color: theme.colors['Surface'],
                          fontFamily: 'Inter_400Regular',
                          fontSize: 12,
                          marginRight: 3,
                          textDecorationLine: 'underline',
                        }
                      ),
                      dimensions.width
                    )}
                  >
                    {'Edit phone number'}
                  </Text>
                  {/* si44 */}
                  <Icon
                    color={theme.colors['Surface']}
                    name={'AntDesign/edit'}
                    size={16}
                  />
                </View>
              </Touchable>
            </View>
          </AccordionGroup>
          {/* spr1 2 */}
          <Spacer bottom={8} left={8} right={8} top={8} />
          {/* sacc66 */}
          <AccordionGroup
            caretSize={24}
            expanded={false}
            iconSize={24}
            {...GlobalStyles.AccordionGroupStyles(theme)['Accordion'].props}
            caretColor={theme.colors['Surface']}
            closedColor={theme.colors['Surface']}
            icon={'MaterialIcons/perm-camera-mic'}
            label={'Permissions'}
            openColor={theme.colors['Surface']}
            style={StyleSheet.applyWidth(
              StyleSheet.compose(
                GlobalStyles.AccordionGroupStyles(theme)['Accordion'].style,
                {
                  color: theme.colors['Surface'],
                  fontFamily: 'Inter_400Regular',
                  fontSize: 14,
                }
              ),
              dimensions.width
            )}
          >
            {/* svv77 */}
            <View
              style={StyleSheet.applyWidth(
                {
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  marginLeft: 20,
                  marginRight: 20,
                  marginTop: 10,
                },
                dimensions.width
              )}
            >
              {/* stt88 */}
              <Text
                accessible={true}
                {...GlobalStyles.TextStyles(theme)['Text 2'].props}
                style={StyleSheet.applyWidth(
                  StyleSheet.compose(
                    GlobalStyles.TextStyles(theme)['Text 2'].style,
                    {
                      color: theme.colors['Surface'],
                      fontFamily: 'Inter_400Regular',
                      fontSize: 12,
                    }
                  ),
                  dimensions.width
                )}
              >
                {'Location access'}
              </Text>
              {/* ssw99 */}
              <Switch
                onValueChange={newSsw99Value => {
                  try {
                    setGlobalVariableValue({
                      key: 'onLoc',
                      value: -newSsw99Value,
                    });
                    console.log(newSsw99Value);
                  } catch (err) {
                    console.error(err);
                  }
                }}
                activeThumbColor={theme.colors['Surface']}
                activeTrackColor={theme.colors['Secondary']}
                value={switchValue2}
              />
            </View>
            {/* svv111 */}
            <View
              style={StyleSheet.applyWidth(
                {
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  marginLeft: 20,
                  marginRight: 20,
                  marginTop: 10,
                },
                dimensions.width
              )}
            >
              {/* stt222 */}
              <Text
                accessible={true}
                {...GlobalStyles.TextStyles(theme)['Text 2'].props}
                style={StyleSheet.applyWidth(
                  StyleSheet.compose(
                    GlobalStyles.TextStyles(theme)['Text 2'].style,
                    {
                      color: theme.colors['Surface'],
                      fontFamily: 'Inter_400Regular',
                      fontSize: 12,
                    }
                  ),
                  dimensions.width
                )}
              >
                {'Notifications'}
              </Text>
              {/* ssw333 */}
              <Switch
                onValueChange={newSsw333Value => {
                  try {
                    setGlobalVariableValue({
                      key: 'onNotif',
                      value: -newSsw333Value,
                    });
                    console.log(newSsw333Value);
                  } catch (err) {
                    console.error(err);
                  }
                }}
                activeThumbColor={theme.colors['Surface']}
                activeTrackColor={theme.colors['Secondary']}
                value={Constants['onNotif']}
              />
            </View>
          </AccordionGroup>
          {/* spr1 3 */}
          <Spacer bottom={8} left={8} right={8} top={8} />
          {/* sacc555 */}
          <AccordionGroup
            caretSize={24}
            expanded={false}
            iconSize={24}
            {...GlobalStyles.AccordionGroupStyles(theme)['Accordion'].props}
            caretColor={theme.colors['Surface']}
            closedColor={theme.colors['Surface']}
            icon={'Feather/tool'}
            label={'Resources'}
            openColor={theme.colors['Surface']}
            style={StyleSheet.applyWidth(
              StyleSheet.compose(
                GlobalStyles.AccordionGroupStyles(theme)['Accordion'].style,
                {
                  color: theme.colors['Surface'],
                  fontFamily: 'Inter_400Regular',
                  fontSize: 14,
                }
              ),
              dimensions.width
            )}
          >
            {/* svv666 */}
            <View
              style={StyleSheet.applyWidth(
                { marginLeft: 20, marginRight: 20, marginTop: 10 },
                dimensions.width
              )}
            >
              {/* stt777 */}
              <Text
                accessible={true}
                {...GlobalStyles.TextStyles(theme)['Text 2'].props}
                style={StyleSheet.applyWidth(
                  StyleSheet.compose(
                    GlobalStyles.TextStyles(theme)['Text 2'].style,
                    {
                      color: theme.colors['Surface'],
                      fontFamily: 'Inter_400Regular',
                      fontSize: 12,
                    }
                  ),
                  dimensions.width
                )}
              >
                {
                  'Draftbit\nCanva\nReact Native\nVSCode\nExpo / Expo Go\n\nlifeline. created by CSS152L BM4 Group 2'
                }
              </Text>
            </View>
          </AccordionGroup>
        </View>
      </SimpleStyleScrollView>
      {/* settbyu */}
      <View
        style={StyleSheet.applyWidth(
          { bottom: 0, position: 'absolute', width: '100%' },
          dimensions.width
        )}
      >
        <SettNBBlock />
      </View>
      {/* New Num Modal */}
      <>
        {!isTrue(NewNumModal) ? null : (
          <Modal animationType={'slide'} transparent={true}>
            {/* nnmbg */}
            <View
              style={StyleSheet.applyWidth(
                { backgroundColor: theme.colors['Strong'], opacity: 0.4 },
                dimensions.width
              )}
            />
            {/* nnmkav */}
            <KeyboardAvoidingView
              behavior={'padding'}
              enabled={true}
              keyboardVerticalOffset={0}
              style={StyleSheet.applyWidth(
                {
                  backgroundColor: theme.colors['Secondary'],
                  bottom: 0,
                  height: '30%',
                  justifyContent: 'center',
                  left: 0,
                  paddingBottom: 15,
                  position: 'absolute',
                  right: 0,
                  width: '100%',
                },
                dimensions.width
              )}
            >
              {/* NASABABA */}
              <View
                style={StyleSheet.applyWidth(
                  {
                    alignItems: 'center',
                    gap: 20,
                    justifyContent: 'flex-start',
                  },
                  dimensions.width
                )}
              >
                {/* nnmv */}
                <View
                  style={StyleSheet.applyWidth(
                    {
                      alignSelf: 'flex-start',
                      flexDirection: 'row',
                      marginLeft: 20,
                      top: 3,
                    },
                    dimensions.width
                  )}
                >
                  {/* nnmib */}
                  <IconButton
                    onPress={() => {
                      try {
                        navigation.goBack();
                      } catch (err) {
                        console.error(err);
                      }
                    }}
                    size={32}
                    icon={'AntDesign/left'}
                  />
                </View>
                {/* nnmt */}
                <Text
                  accessible={true}
                  {...GlobalStyles.TextStyles(theme)['Text'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextStyles(theme)['Text'].style,
                      {
                        color: theme.colors['Primary'],
                        fontFamily: 'Inter_700Bold',
                        fontSize: 16,
                        textTransform: 'uppercase',
                      }
                    ),
                    dimensions.width
                  )}
                >
                  {'Enter new phone number'}
                </Text>
                {/* nnmti */}
                <TextInput
                  autoCapitalize={'none'}
                  autoCorrect={true}
                  changeTextDelay={500}
                  onChangeText={newNnmtiValue => {
                    try {
                      setGlobalVariableValue({
                        key: 'phoneNum',
                        value: newNnmtiValue,
                      });
                    } catch (err) {
                      console.error(err);
                    }
                  }}
                  webShowOutline={true}
                  {...GlobalStyles.TextInputStyles(theme)['Text Input'].props}
                  keyboardType={'phone-pad'}
                  maxLength={11}
                  placeholder={'09XXXXXXXXX'}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.TextInputStyles(theme)['Text Input'].style,
                      { backgroundColor: theme.colors['Surface'], width: '50%' }
                    ),
                    dimensions.width
                  )}
                  value={Constants['phoneNum']}
                />
                {/* nnmb */}
                <Button
                  onPress={() => {
                    try {
                      if (is11(Constants['phoneNum'])) {
                        setNewOTPModal(1);
                      }
                    } catch (err) {
                      console.error(err);
                    }
                  }}
                  {...GlobalStyles.ButtonStyles(theme)['Button'].props}
                  style={StyleSheet.applyWidth(
                    StyleSheet.compose(
                      GlobalStyles.ButtonStyles(theme)['Button'].style,
                      { fontFamily: 'Inter_700Bold', width: '50%' }
                    ),
                    dimensions.width
                  )}
                  title={'VERIFY'}
                />
              </View>
            </KeyboardAvoidingView>
          </Modal>
        )}
      </>
      {/* New OTP Modal */}
      <>
        {!NewOTPModal ? null : (
          <Modal animationType={'slide'} transparent={true}>
            {/* nombg */}
            <View
              style={StyleSheet.applyWidth(
                { backgroundColor: theme.colors['Strong'], opacity: 0.3 },
                dimensions.width
              )}
            />
            {/* nomkav */}
            <KeyboardAvoidingView
              behavior={'padding'}
              enabled={true}
              keyboardVerticalOffset={0}
              style={StyleSheet.applyWidth(
                {
                  alignItems: 'center',
                  backgroundColor: theme.colors['Secondary'],
                  bottom: 0,
                  gap: 30,
                  height: '40%',
                  justifyContent: 'flex-start',
                  position: 'absolute',
                  width: '100%',
                },
                dimensions.width
              )}
            >
              {/* nomv */}
              <View
                style={StyleSheet.applyWidth(
                  {
                    alignItems: 'flex-start',
                    alignSelf: 'flex-start',
                    flexDirection: 'row',
                    marginLeft: 20,
                    marginTop: 15,
                  },
                  dimensions.width
                )}
              >
                {/* nomib */}
                <IconButton
                  onPress={() => {
                    try {
                      navigation.goBack();
                    } catch (err) {
                      console.error(err);
                    }
                  }}
                  size={32}
                  icon={'AntDesign/left'}
                />
              </View>
              {/* nomt */}
              <Text
                accessible={true}
                {...GlobalStyles.TextStyles(theme)['Text'].props}
                style={StyleSheet.applyWidth(
                  StyleSheet.compose(
                    GlobalStyles.TextStyles(theme)['Text'].style,
                    {
                      color: theme.colors['Primary'],
                      fontFamily: 'Inter_700Bold',
                      fontSize: 16,
                      textTransform: 'uppercase',
                    }
                  ),
                  dimensions.width
                )}
              >
                {'Enter OTP'}
              </Text>
              {/* nom4ti */}
              <View
                style={StyleSheet.applyWidth(
                  { flexDirection: 'row', width: '70%' },
                  dimensions.width
                )}
              >
                {/* nom4ti1 */}
                <View
                  style={StyleSheet.applyWidth(
                    {
                      backgroundColor: theme.colors.studilyWhite3,
                      borderBottomWidth: 1,
                      borderColor: theme.colors.studilyGray4,
                      borderLeftWidth: 1,
                      borderRadius: 12,
                      borderRightWidth: 1,
                      borderTopWidth: 1,
                      flex: 1,
                      overflow: 'hidden',
                    },
                    dimensions.width
                  )}
                >
                  {/* nom4ti12 */}
                  <View
                    style={StyleSheet.applyWidth(
                      {
                        paddingBottom: 16,
                        paddingLeft: 16,
                        paddingRight: 16,
                        paddingTop: 16,
                      },
                      dimensions.width
                    )}
                  >
                    {/* nom4ti13 */}
                    <TextInput
                      autoCapitalize={'none'}
                      autoCorrect={true}
                      changeTextDelay={500}
                      placeholder={'Enter a value...'}
                      webShowOutline={true}
                      defaultValue={input1}
                      editable={isTrue()}
                      keyboardType={'numeric'}
                      maxLength={1}
                      style={StyleSheet.applyWidth(
                        {
                          color: theme.colors.studilyMediumUI,
                          fontFamily: 'Inter_500Medium',
                          fontSize: 24,
                          textAlign: 'center',
                        },
                        dimensions.width
                      )}
                    />
                  </View>
                </View>
                {/* nom4ti15 */}
                <Spacer bottom={8} left={8} right={8} top={8} />
                {/* nom4ti16 */}
                <View
                  style={StyleSheet.applyWidth(
                    {
                      backgroundColor: theme.colors.studilyWhite3,
                      borderBottomWidth: 1,
                      borderColor: theme.colors.studilyGray4,
                      borderLeftWidth: 1,
                      borderRadius: 12,
                      borderRightWidth: 1,
                      borderTopWidth: 1,
                      flex: 1,
                      overflow: 'hidden',
                    },
                    dimensions.width
                  )}
                >
                  {/* nom4ti17 */}
                  <View
                    style={StyleSheet.applyWidth(
                      {
                        paddingBottom: 16,
                        paddingLeft: 16,
                        paddingRight: 16,
                        paddingTop: 16,
                      },
                      dimensions.width
                    )}
                  >
                    {/* nom4ti18 */}
                    <TextInput
                      autoCapitalize={'none'}
                      autoCorrect={true}
                      changeTextDelay={500}
                      placeholder={'Enter a value...'}
                      webShowOutline={true}
                      defaultValue={input2}
                      editable={isTrue()}
                      keyboardType={'numeric'}
                      maxLength={1}
                      style={StyleSheet.applyWidth(
                        {
                          color: theme.colors.studilyMediumUI,
                          fontFamily: 'Inter_500Medium',
                          fontSize: 24,
                          textAlign: 'center',
                        },
                        dimensions.width
                      )}
                    />
                  </View>
                </View>
                {/* nom4ti19 */}
                <Spacer bottom={8} left={8} right={8} top={8} />
                {/* nom4ti2 */}
                <View
                  style={StyleSheet.applyWidth(
                    {
                      backgroundColor: theme.colors.studilyWhite3,
                      borderBottomWidth: 1,
                      borderColor: theme.colors.studilyGray4,
                      borderLeftWidth: 1,
                      borderRadius: 12,
                      borderRightWidth: 1,
                      borderTopWidth: 1,
                      flex: 1,
                      overflow: 'hidden',
                    },
                    dimensions.width
                  )}
                >
                  {/* nom4ti21 */}
                  <View
                    style={StyleSheet.applyWidth(
                      {
                        paddingBottom: 16,
                        paddingLeft: 16,
                        paddingRight: 16,
                        paddingTop: 16,
                      },
                      dimensions.width
                    )}
                  >
                    {/* nom4ti22 */}
                    <TextInput
                      autoCapitalize={'none'}
                      autoCorrect={true}
                      changeTextDelay={500}
                      placeholder={'Enter a value...'}
                      webShowOutline={true}
                      defaultValue={input3}
                      editable={isTrue()}
                      keyboardType={'numeric'}
                      maxLength={1}
                      style={StyleSheet.applyWidth(
                        {
                          color: theme.colors.studilyMediumUI,
                          fontFamily: 'Inter_500Medium',
                          fontSize: 24,
                          textAlign: 'center',
                        },
                        dimensions.width
                      )}
                    />
                  </View>
                </View>
                {/* nom4ti23 */}
                <Spacer bottom={8} left={8} right={8} top={8} />
                {/* nom4ti24 */}
                <View
                  style={StyleSheet.applyWidth(
                    {
                      backgroundColor: theme.colors.studilyWhite3,
                      borderBottomWidth: 1,
                      borderColor: theme.colors.studilyGray4,
                      borderLeftWidth: 1,
                      borderRadius: 12,
                      borderRightWidth: 1,
                      borderTopWidth: 1,
                      flex: 1,
                      overflow: 'hidden',
                    },
                    dimensions.width
                  )}
                >
                  {/* nom4ti25 */}
                  <View
                    style={StyleSheet.applyWidth(
                      {
                        paddingBottom: 16,
                        paddingLeft: 16,
                        paddingRight: 16,
                        paddingTop: 16,
                      },
                      dimensions.width
                    )}
                  >
                    {/* nom4ti26 */}
                    <TextInput
                      autoCapitalize={'none'}
                      autoCorrect={true}
                      changeTextDelay={500}
                      placeholder={'Enter a value...'}
                      webShowOutline={true}
                      defaultValue={input4}
                      editable={isTrue()}
                      keyboardType={'numeric'}
                      maxLength={1}
                      style={StyleSheet.applyWidth(
                        {
                          color: theme.colors.studilyMediumUI,
                          fontFamily: 'Inter_500Medium',
                          fontSize: 24,
                          textAlign: 'center',
                        },
                        dimensions.width
                      )}
                    />
                  </View>
                </View>
              </View>
              {/* nomb */}
              <Button
                onPress={() => {
                  try {
                    if (navigation.canGoBack()) {
                      navigation.popToTop();
                    }
                    navigation.replace('SettingsScreen');
                  } catch (err) {
                    console.error(err);
                  }
                }}
                {...GlobalStyles.ButtonStyles(theme)['Button'].props}
                style={StyleSheet.applyWidth(
                  StyleSheet.compose(
                    GlobalStyles.ButtonStyles(theme)['Button'].style,
                    { fontFamily: 'Inter_700Bold', width: '50%' }
                  ),
                  dimensions.width
                )}
                title={'SUBMIT'}
              />
            </KeyboardAvoidingView>
          </Modal>
        )}
      </>
    </ScreenContainer>
  );
};

export default withTheme(SettingsScreen);
