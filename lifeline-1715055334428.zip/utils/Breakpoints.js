export default {
  Mobile: 0,
  Tablet: 480,
  Laptop: 992,
  Desktop: 1440,
  BigScreen: 1920,
};
